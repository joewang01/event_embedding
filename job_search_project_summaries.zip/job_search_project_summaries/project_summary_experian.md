# Experian — ECL Data Processing for Insurance Pre-Screening

## 1. Executive Summary
Built ECL (Enterprise Control Language) data processing pipelines for Experian attributes used in insurance pre-screening. The project processes Experian inquiry data with grouping and temporal analysis on the HPCC distributed computing platform, building derived attributes for downstream scoring models.

## 2. Business / Product Background
Experian data provides credit and inquiry attributes valuable for insurance pre-screening and risk assessment. The pipelines:
- Process raw Experian attribute data into model-ready features
- Extract temporal patterns from Experian inquiry data
- Support pre-screening products with enriched attribute sets
- Integrate with existing insurance scoring infrastructure

## 3. Data Background
- **Processing scripts**: Proc_Build_ExperianAttributes.ecl, Proc_Find_ExperianFileCreationDate.ecl
- **Documentation**: Smart V4.0 Documentation.xls — attribute specification
- **Data type**: Experian credit/inquiry attributes
- **Platform**: HPCC Systems (distributed processing)

## 4. Technical Approach
- ECL scripts for distributed data processing on HPCC
- Attribute building from raw Experian inquiry data
- Temporal analysis (file creation date tracking)
- Grouping operations for attribute aggregation

## 5. My Role and Contribution
- Developed ECL pipelines for Experian attribute processing
- Built temporal analysis for inquiry pattern extraction
- Integrated Experian attributes into pre-screening pipeline

## 6. Key Results and Impact
- Automated Experian attribute processing for insurance pre-screening
- Temporal features extracted from inquiry data for model enrichment
- Integration with existing HPCC scoring infrastructure

## 7. Challenges and Solutions
- **Data Volume**: Experian data at national scale → Distributed processing via HPCC Thor cluster

## 8. Job Application Story
- **Situation**: Insurance pre-screening products needed enriched features from Experian credit and inquiry data to improve predictive accuracy for marketing campaigns.
- **Task**: I built the ECL data processing pipelines for Experian attribute extraction, enabling the team to incorporate credit-based features into insurance scoring models.
- **Action**: I developed distributed processing scripts on HPCC for attribute building, temporal analysis of inquiry patterns, and grouping operations that transformed raw Experian data into model-ready features.
- **Result**: Delivered automated Experian attribute pipelines enabling enriched pre-screening with credit and inquiry-based features, expanding the feature set available to all downstream insurance scoring models.

## 9. Relevant Skills Demonstrated
- ECL / HPCC Systems, data engineering, credit data processing, feature engineering

## 10. Best-Fit Job Types
- Data Engineer, Data Scientist, Analytics Engineer

## 11. Resume Bullet Suggestions
- Built ECL data pipelines on HPCC for Experian attribute processing, enabling enriched insurance pre-screening with temporal inquiry features
- Developed distributed feature engineering pipeline transforming raw credit data into model-ready attributes for downstream insurance scoring
- Designed temporal analysis logic extracting inquiry frequency patterns from Experian data for predictive marketing applications

## 12. Interview Talking Points
- "I built distributed ECL pipelines for processing Experian credit data, extracting temporal inquiry patterns that became features in insurance pre-screening models."
- "Credit inquiry patterns are highly predictive for insurance marketing — the temporal features I engineered captured shopping behavior that static credit data misses."

## 13. Evidence Found
- **Proc_Build_ExperianAttributes.ecl** — Attribute building pipeline
- **Proc_Find_ExperianFileCreationDate.ecl** — Temporal analysis script
- **Smart V4.0 Documentation.xls** — Attribute documentation
