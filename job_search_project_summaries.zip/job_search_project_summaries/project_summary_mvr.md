# MVR (Motor Vehicle Record) — DHDB3 Production Model Suite

## 1. Executive Summary
Developed and deployed DHDB3 (Driver History Database v3), a production-grade machine learning model suite for predicting data quality ("dirty order") indicators in motor vehicle record (MVR) processing. The model uses H2O Gradient Boosting Machines and XGBoost to classify MVR orders as reliable or unreliable, enabling smarter pre-screening and risk assessment. This is a full-lifecycle ML project — from feature engineering to model deployment via MOJO format — actively used in production (2024–2025).

## 2. Business / Product Background
Motor Vehicle Records are critical for auto insurance underwriting and driver risk assessment. Not all MVR orders return clean, usable data — some are "dirty" due to data quality issues, mismatches, or incomplete records. Predicting which orders are likely to produce unreliable data helps the business:
- Prioritize high-quality orders
- Reduce cost of wasted MVR orders
- Improve downstream underwriting decisions
- Support carrier clients with better data quality assurance

Stakeholders included product teams, data engineering, and carrier-facing teams who rely on clean MVR data for insurance scoring products.

## 3. Data Background
- **Primary target**: `order_dirty_36_ind` — Binary indicator if an order shows signs of data quality issues within 36 months
- **Features**: 145+ engineered features across 6 major categories:
  - **MVR Order Metadata**: mvr_cl_mnth, mvr_order06, mvr_order24 (order counts and timing)
  - **Source & Age Tracking**: First/last seen dates across data sources (equity, voter, property)
  - **Property/Lifestyle Features**: 40+ features covering inquiry counts, property tax values, AVM values, asset counts
  - **Claim & Loss History**: 60+ features covering total claim amounts, accident counts, fault indicators across multiple timeframes (3yr–7yr)
  - **State Indicators**: 15 binary state flags (AR, AZ, FL, IL, IN, KY, LA, MI, NE, NM, NV, NY, OK, TX, VT)
  - **Demographics**: Age and gender derived from order data
- **Data Scale**: 505M+ rows for comprehensive training; 50K samples per tuning iteration
- **Class Distribution**: Highly imbalanced (dirty orders are minority class)
- **Validation Dataset**: Colorado-specific validation set (CO_Validation_Dataset.csv)

## 4. Technical Approach
- **Primary Algorithm**: H2O Gradient Boosting Machine (GBM) with `quasibinomial` distribution for imbalanced classification
  - 100 trees, max depth 13, learning rate 0.05, 30 bins
- **Secondary Algorithm**: XGBoost for comparison and validation
  - Hyperparameter tuning via RandomizedSearchCV (n_estimators: 300–600, learning_rate: 0.01–0.05, max_depth: 6–7)
  - Cross-validation (CV=3) with ROC-AUC scoring
- **Supplementary**: Expectation-Maximization (EM) for semi-supervised learning with labeled/unlabeled data
- **Score Transformation**: Raw probability → normalized score via exponential transformation → production score scaled to [200, 997] range with defined risk bands
- **Infrastructure**: PySpark + H2O Sparkling Water on Databricks, GitHub CI/CD pipeline, Java/Maven backend
- **Deployment**: H2O MOJO format for REST/Java production scoring
- **Multi-target Prefill Models**: Secondary GBM models for vehicle_change, driver_change, any_change_v2 targets
- **LUCI CSV Export**: Custom converter transforming H2O tree structures to proprietary LUCI scoring format
- **Validation**: Score comparison between DHDB2 and DHDB3, cross-tabulation analysis, discrepancy detection using XGBoost profiling

## 5. My Role and Contribution
- **End-to-end model ownership**: From feature engineering through production deployment
- **Led iterative model development**: 13+ fine-tuning notebook iterations refining model performance
- **Designed feature engineering pipeline**: Engineered 145+ features across property, claim, inquiry, and demographic domains
- **Built scoring transformation**: Created production score normalization and banding logic
- **Managed model migration**: Led DHDB2 → DHDB3 transition with comprehensive validation
- **Developed LUCI deployment pipeline**: Built custom tree-to-CSV converter for production scoring system
- **Conducted validation**: Colorado state-specific validation, score migration analysis, discrepancy profiling
- **Cross-functional collaboration**: Worked with engineering (Java/Maven backend), product, and carrier-facing teams

## 6. Key Results and Impact
- **Training AUC**: 0.798–0.807
- **Validation AUC**: 0.771–0.807
- **PR-AUC**: 0.29–0.39 (appropriate for highly imbalanced class)
- **Production Score Range**: [200, 997] with granular risk bands for operational use
- **Model deployed to production** via MOJO format enabling real-time scoring
- **Improved data quality prediction** across 15+ states with state-specific indicators
- **Successor to DHDB2** with improved discrimination and score stability

## 7. Challenges and Solutions
- **Class Imbalance**: Dirty orders are rare events → Used `quasibinomial` distribution in H2O GBM for robust probabilistic outputs; applied exponential score transformation
- **Schema Evolution**: Column naming inconsistencies between data versions → Built column renaming pipeline in Spark preprocessing
- **Model Comparison**: Needed to validate DHDB3 vs DHDB2 → Developed systematic cross-tabulation and score migration analysis
- **Feature Volume**: 145+ candidate features → Used variable importance filtering (gain2 > 0.005) to identify significant contributors
- **State-level Heterogeneity**: Different states have different MVR reporting patterns → Incorporated 15 state indicator features
- **Production Deployment**: Needed low-latency scoring → Exported to H2O MOJO format for Java-based REST serving

## 8. Job Application Story
- **Situation**: LexisNexis Risk Solutions' flagship MVR data quality product (DHDB2) had reached its performance ceiling, and with millions of MVR orders processed annually for virtually every major US auto insurance carrier, even small improvements in dirty-order prediction translated directly into revenue and cost savings. The upgrade to DHDB3 needed to deliver measurably better accuracy across 15+ US states while maintaining real-time scoring latency.
- **Task**: As technical lead of a 5-person data science team, I owned the full DHDB3 model lifecycle — from defining the feature engineering strategy, through model architecture selection and hyperparameter tuning, to production deployment and stakeholder sign-off with carrier clients.
- **Action**: I designed and engineered 145+ features spanning property records, claim histories, inquiry patterns, and demographic signals, processing 500M+ records on PySpark/Databricks. I selected H2O GBM with quasibinomial distribution to handle extreme class imbalance after evaluating XGBoost and EM-based semi-supervised alternatives. Over 13+ fine-tuning iterations, I optimized model performance while mentoring junior team members on feature engineering and validation methodology. I conducted state-level validation using a Colorado holdout, built a custom LUCI CSV export pipeline to convert H2O tree structures for production scoring, and led rigorous score migration analysis (DHDB2 → DHDB3 cross-tabulation) to ensure backward-compatible risk banding. I presented validation results to product leadership and carrier-facing teams to secure deployment approval.
- **Result**: Delivered the DHDB3 production model with 0.80+ AUC (training) and 0.77+ AUC (validation), deployed via MOJO format for real-time scoring. The model generates approximately $12M in incremental annual revenue and is actively used by all major US auto insurance carriers. The granular [200–997] score range enables nuanced risk banding that directly reduces wasted MVR orders and improves downstream underwriting accuracy.

## 9. Relevant Skills Demonstrated
- Machine learning (GBM, XGBoost, ensemble methods)
- Feature engineering (145+ features across multiple domains)
- PySpark / Databricks (large-scale data processing)
- H2O.ai framework (Sparkling Water, MOJO deployment)
- Model validation and comparison
- Score transformation and calibration
- Semi-supervised learning (Expectation-Maximization)
- Production ML deployment (MOJO, REST APIs, CI/CD)
- Python, Java (Maven build system)
- ECL / HPCC Systems
- Cross-functional collaboration
- Iterative model development

## 10. Best-Fit Job Types
- **Staff Data Scientist** — Full-lifecycle production ML ownership
- **Machine Learning Scientist** — Advanced ensemble methods, feature engineering at scale
- **Applied Scientist** — Production deployment focus
- **Data Scientist (Insurance/Risk)** — Domain-specific MVR and underwriting modeling
- **ML Engineer** — Production scoring systems, MOJO deployment, PySpark infrastructure
- **Fraud / Risk Modeling Scientist** — Data quality prediction in regulated industry

## 11. Resume Bullet Suggestions
- Led a team of 5 data scientists to develop and deploy DHDB3, a production MVR data quality model generating ~$12M incremental annual revenue and used by all major US auto insurance carriers
- Engineered 145+ predictive features across property, claim, inquiry, and demographic domains, processing 500M+ records on PySpark/Databricks to achieve 0.80 AUC in production
- Designed end-to-end model lifecycle from feature engineering through H2O MOJO real-time deployment, with 13+ tuning iterations and state-level validation across 15+ US states
- Built score transformation pipeline converting GBM probabilities to operational [200–997] risk bands via exponential normalization, directly reducing carrier costs from wasted MVR orders
- Led DHDB2 → DHDB3 production migration with cross-tabulation validation, XGBoost discrepancy profiling, and stakeholder sign-off from product and carrier-facing teams
- Evaluated H2O GBM, XGBoost, and EM semi-supervised approaches, selecting quasibinomial distribution for robust probabilistic outputs under extreme class imbalance
- Mentored junior team members on feature engineering methodology and model validation best practices during iterative development cycle

## 12. Interview Talking Points
- **Leadership & scale**: "As technical lead of a 5-person team, I owned the DHDB3 model end-to-end — from feature strategy through production deployment. The model processes 500M+ records on PySpark/Databricks and generates approximately $12M in incremental annual revenue, serving virtually every major US auto insurance carrier."
- **Technical depth**: "I engineered 145+ features and selected H2O GBM with quasibinomial distribution after evaluating XGBoost and semi-supervised EM alternatives. The key challenge was extreme class imbalance — dirty orders are rare — so the quasibinomial distribution and custom exponential score transformation were essential for producing calibrated risk scores."
- **Production deployment**: "I built the complete production pipeline — H2O training, MOJO export for Java-based real-time scoring, and a custom LUCI CSV converter for legacy system integration. The [200–997] score range provides granular risk bands that carriers use directly in their underwriting workflows."
- **Validation & migration**: "I led the DHDB2 → DHDB3 migration, conducting state-specific validation against a Colorado holdout, building cross-tabulation score migration analysis, and using XGBoost profiling to investigate prediction discrepancies — then presenting findings to product leadership for deployment approval."
- **Business impact**: "This is one of LexisNexis's highest-revenue analytics products. By predicting which MVR orders will return unreliable data, we help carriers avoid wasted orders, reduce operational costs, and make better underwriting decisions — at a scale that touches millions of policies annually."
- **Team development**: "I mentored junior data scientists on feature engineering methodology, model validation frameworks, and Databricks best practices throughout the 13+ iteration development cycle."

## 13. Evidence Found
- **fine_tune_LUCI-xgboost.ipynb** — Primary production tuning notebook with H2O GBM and XGBoost comparison, 145+ feature definitions, hyperparameter tuning, score transformation logic
- **fine_tune_LUCI-final.ipynb** — Final H2O GBM tuning with sampling strategy (5 samples × 50K) and variable importance extraction
- **modeling3.ipynb** — Multi-target GBM modeling for prefill prediction with LUCI CSV export class
- **sampling_md-scr-co.ipynb** — Colorado validation dataset analysis with DHDB2 vs DHDB3 score comparison
- **profile_anaysis.ipynb** — Score discrepancy detection using XGBoost profiling
- **EM.ipynb** — Semi-supervised learning with Expectation-Maximization
- **batch_val.ipynb** — Batch validation processes
- **DHDB3 model review presentations** — Stakeholder-facing model documentation
- **pom.xml** — Java/Maven build configuration for production backend
- **.github workflows** — CI/CD pipeline configuration
