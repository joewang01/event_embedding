# ITMM — Integrated Tenure Marketing Model

## 1. Executive Summary
Developed the Integrated Tenure Marketing Model (ITMM) — a predictive model for insurance tenure/retention targeting using InsurView prescreen attributes. The project includes comprehensive model results, detailed attribute documentation, and multiple iterations showing model refinement with heavy stakeholder communication through presentations and training materials.

## 2. Business / Product Background
ITMM predicts customer tenure (how long a customer will stay with a carrier) for marketing optimization:
- Enables targeted retention campaigns for at-risk customers
- Supports acquisition targeting by predicting long-tenure prospects
- Leverages InsurView prescreen attributes for model inputs
- Provides actionable tenure predictions for campaign planning

## 3. Data Background
- **Model results**: ITMM_model_comprehensive_result.xlsx — full performance metrics
- **Model summaries**: itmm_model_summary_v3.xlsx — Version 3 model summary
- **Attribute documentation**: IMTT_Model_Prescreen_Attributes_v4.pptx — InsurView attribute specs
- **Training materials**: InsurView training documentation
- **Multiple update presentations**: itmm_update presentations for stakeholder communication

## 4. Technical Approach
- **Predictive Modeling**: Tenure prediction for insurance customer lifecycle
- **InsurView Attributes**: Leveraging prescreen data (claims, inquiry, property signals)
- **Model Versioning**: Progressive refinement (v3+ model summary, v4 attribute specs)
- **Comprehensive Validation**: Full result documentation with performance metrics

## 5. My Role and Contribution
- Developed ITMM predictive model through multiple iterations
- Documented InsurView prescreen attributes for model design (v4)
- Produced comprehensive model result documentation
- Created training materials for InsurView platform
- Delivered multiple stakeholder update presentations

## 6. Key Results and Impact
- Delivered comprehensive tenure prediction model for marketing applications
- InsurView attribute integration enriches model with prescreen signals
- Training materials support ongoing team capability development
- Multiple iterations demonstrate continuous model improvement

## 7. Challenges and Solutions
- **Attribute Complexity**: InsurView has many prescreen attributes → Created v4 attribute documentation clarifying feature usage and importance
- **Stakeholder Alignment**: Multiple teams rely on ITMM → Delivered regular update presentations and training materials

## 8. Job Application Story
- **Situation**: Insurance carriers needed to predict customer tenure — how long a policyholder would stay — to optimize both retention campaigns for at-risk customers and acquisition campaigns targeting high-lifetime-value prospects.
- **Task**: I owned the development of the Integrated Tenure Marketing Model (ITMM), including model building, InsurView attribute documentation, and stakeholder presentations.
- **Action**: I built the tenure prediction model through multiple iterations using InsurView prescreen attributes, documented the v4 attribute specification that became the team's reference guide, and delivered comprehensive results with update presentations to stakeholders demonstrating progressive performance improvement.
- **Result**: Delivered a production-ready tenure marketing model with comprehensive documentation, enabling carriers to target retention campaigns at at-risk customers and acquisition campaigns at high-tenure prospects — a dual-use model that served both marketing objectives.

## 9. Relevant Skills Demonstrated
- Predictive modeling (tenure/retention)
- Feature engineering (InsurView attributes)
- Model documentation and validation
- Stakeholder communication
- Training material development
- Insurance domain expertise

## 10. Best-Fit Job Types
- Data Scientist (Marketing/Insurance)
- Product Data Scientist
- Applied Scientist

## 11. Resume Bullet Suggestions
- Developed Integrated Tenure Marketing Model (ITMM) using InsurView prescreen attributes for insurance customer lifecycle prediction
- Created comprehensive model documentation including v4 attribute specification and InsurView training materials
- Delivered iterative model updates with stakeholder presentations demonstrating progressive performance improvement

## 12. Interview Talking Points
- "ITMM predicts how long a customer will stay with a carrier — high-tenure prospects are more valuable for acquisition, while short-tenure predictions trigger retention campaigns. It's a dual-use model."
- "I created the InsurView v4 attribute documentation that became the reference guide for the team — knowledge sharing that scaled beyond my individual work."

## 13. Evidence Found
- **ITMM_model_comprehensive_result.xlsx** — Full model results
- **itmm_model_summary_v3.xlsx** — Version 3 summary
- **IMTT_Model_Prescreen_Attributes_v4.pptx** — Attribute documentation
- **InsurView training materials** — Platform training docs
- **itmm_update presentations** — Stakeholder updates
