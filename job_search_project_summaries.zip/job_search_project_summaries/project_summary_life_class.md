# Life Class — Life Classification and Mortality Models

## 1. Executive Summary
Developed life classification and mortality models with market view attributes through 5+ model iterations (v1–v5+). The project includes a Puerto Rico non-FCRA mortality model variant and scorecard methodology, representing comprehensive life insurance risk classification work.

## 2. Business / Product Background
Life insurance classification and mortality models:
- Predict mortality risk for underwriting decisions
- Classify applicants into risk categories
- Support both FCRA and non-FCRA compliant use cases
- Market view attributes provide enrichment for improved accuracy
- Puerto Rico-specific model for regional market

## 3. Data Background
- **Model documentation**: Life_classification_model_marketview_v5_w_orig.xlsx (v1–v5+)
- **Mortality model**: PR_NonFCRA_mortality_model_v2 — Puerto Rico non-FCRA variant
- **Scoring**: scorecard.txt — scoring methodology

## 4. Technical Approach
- Classification modeling for life insurance risk tiers
- Mortality prediction with market view attributes
- FCRA/non-FCRA compliance variants
- Scorecard methodology for production scoring
- 5+ iterative model versions with progressive refinement

## 5. My Role and Contribution
- Developed life classification model through 5+ iterations
- Built Puerto Rico mortality model (non-FCRA)
- Designed scorecard methodology
- Ensured FCRA compliance in model variants

## 6. Key Results and Impact
- 5+ model versions demonstrating iterative improvement
- Puerto Rico-specific mortality model for regional market
- FCRA and non-FCRA variants for different regulatory contexts
- Market view attribute integration for enhanced accuracy

## 7. Challenges and Solutions
- **Regulatory Compliance**: FCRA requirements vary → Built separate FCRA and non-FCRA variants
- **Regional Differences**: Puerto Rico has unique mortality dynamics → Developed PR-specific model

## 8. Job Application Story
- **Situation**: Life insurance underwriting required classification and mortality prediction models that could operate under varying regulatory regimes — FCRA-compliant variants for credit-based attributes and non-FCRA variants for broader data sources, plus region-specific models for markets like Puerto Rico with distinct mortality patterns.
- **Task**: I owned the development of multi-variant life classification models, defining the attribute selection strategy for each regulatory context and managing the iterative validation process.
- **Action**: I developed life classification models through 5+ iterations with market view attributes, built a Puerto Rico-specific mortality model to capture regional demographic and health patterns distinct from the mainland US, and designed scorecard methodology for production deployment. I carefully selected attributes to maintain FCRA compliance in the regulated variant while maximizing predictive power in the non-FCRA version, presenting each iteration to stakeholders for regulatory review.
- **Result**: Delivered multi-variant life classification and mortality models that enabled underwriting decisions across different regulatory contexts, with the Puerto Rico regional model providing market-specific mortality predictions unavailable from generic national models. The 5+ iterations demonstrated measurable improvement in classification accuracy while maintaining full regulatory compliance.

## 9. Relevant Skills Demonstrated
- Mortality modeling, classification, FCRA compliance, scorecard development, life insurance domain

## 10. Best-Fit Job Types
- Data Scientist (Insurance/Risk), Fraud / Risk Modeling Scientist, Applied Scientist

## 11. Resume Bullet Suggestions
- Developed multi-variant life classification and mortality models through 5+ iterations with FCRA-compliant and non-FCRA variants, enabling underwriting across different regulatory regimes
- Built Puerto Rico-specific mortality model capturing regional demographic patterns distinct from mainland US, extending product coverage to underserved market
- Designed scorecard methodology integrating market view attributes for production-deployed life insurance risk classification with full regulatory compliance

## 12. Interview Talking Points
- **Regulatory sophistication**: "I built life classification models in two variants — FCRA-compliant for credit-based attributes and non-FCRA for broader data sources. Attribute selection had to be carefully managed to maintain compliance in the regulated variant while maximizing predictive power in the unrestricted version."
- **Regional modeling**: "Puerto Rico has distinct mortality patterns from the mainland US. I built a region-specific model rather than applying a generic national model, which provided significantly better underwriting accuracy for that market."
- **Iterative validation**: "Five-plus iterations with stakeholder review ensured each version improved classification accuracy while maintaining regulatory compliance — a balance that requires careful attribute curation at each step."

## 13. Evidence Found
- **Life_classification_model_marketview_v5_w_orig.xlsx** — Classification model (v1–v5+)
- **PR_NonFCRA_mortality_model_v2** — Puerto Rico mortality model
- **scorecard.txt** — Scoring methodology
