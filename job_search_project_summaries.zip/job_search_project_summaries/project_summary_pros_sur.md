# Pros_Sur — Prospect Survival Model

## 1. Executive Summary
Developed the Prospect Survival (cross-sell/upsell) predictive model with extensive scorecard documentation spanning 2013–2015. The project includes both FCRA and non-FCRA compliant model versions, ZIP4 and ZIP5 level geographic modeling, and rigorous validation across multiple time periods — representing a key insurance marketing targeting product.

## 2. Business / Product Background
The Prospect Survival model predicts the likelihood that a prospect will "survive" (remain active, convert, or respond) after being targeted, enabling:
- Cross-sell and upsell opportunity identification
- FCRA-compliant scoring for regulated use cases (pre-screening)
- Non-FCRA variants for general marketing
- Geographic precision at ZIP4/ZIP5 levels for localized targeting

## 3. Data Background
- **Model documentation**: pros_sur_model_doc.xlsx (multiple versions)
- **Scorecard deliverables**: pros_sur_scorecard_deliverables_*.xlsx (2013–2014, multiple dates)
- **FCRA compliance**: Both FCRA and non-FCRA model variants (non-fcra/ subfolder)
- **Geographic granularity**: ZIP4 and ZIP5 level modeling
- **Gender analysis**: Included in model segmentation
- **Validation periods**: 2013–2015 timeframe coverage across 19+ files

## 4. Technical Approach
- **Predictive Scorecard**: Traditional scorecard methodology for prospect survival probability
- **FCRA/Non-FCRA Variants**: Separate models meeting regulatory requirements for credit-based pre-screening vs. general marketing
- **Geographic Segmentation**: ZIP4 (9-digit) and ZIP5 (5-digit) level precision for localized scoring
- **Temporal Validation**: Cross-period validation (2013–2015) ensuring model stability
- **Gender Analysis**: Demographic segmentation for targeting precision

## 5. My Role and Contribution
- Built prospect survival predictive scorecards with FCRA and non-FCRA variants
- Designed ZIP4/ZIP5 geographic segmentation for localized targeting
- Managed multi-year validation across 2013–2015 timeframe
- Delivered scorecard deliverables documentation for client deployment
- Ensured regulatory compliance (FCRA) in model design

## 6. Key Results and Impact
- Delivered FCRA-compliant prospect survival model for regulated pre-screening use
- ZIP4/ZIP5 geographic scoring enables fine-grained local targeting
- Multi-year validation (2013–2015) demonstrates model stability and reliability
- Non-FCRA variant available for broader marketing applications

## 7. Challenges and Solutions
- **Regulatory Compliance**: FCRA governs credit-based pre-screening → Built separate FCRA-compliant model variant with appropriate attribute restrictions
- **Geographic Granularity**: Need local-level targeting precision → Implemented both ZIP4 and ZIP5 level scoring
- **Temporal Stability**: Model must perform consistently across years → Cross-validated across 2013–2015 period

## 8. Job Application Story
- **Situation**: Insurance carriers needed regulatory-compliant scoring models to predict prospect survival (likelihood of converting to a policyholder) for pre-screening and cross-sell campaigns, with the additional constraint that FCRA compliance was required for credit-based pre-screening but not for general marketing.
- **Task**: I owned the development of prospect survival scorecards in both FCRA-compliant and non-FCRA variants, defining the geographic segmentation strategy and managing a multi-year validation process.
- **Action**: I developed dual-variant predictive scorecards with ZIP4/ZIP5 geographic segmentation for fine-grained precision, built separate FCRA and non-FCRA model versions with appropriate attribute selection for each regulatory context, and validated across three years (2013–2015) of insurance data to ensure temporal stability. I delivered comprehensive scorecard documentation for client deployment and presented validation results showing the lift advantage of ZIP4-level scoring over ZIP5.
- **Result**: Delivered a dual-variant prospect survival model system enabling both regulated pre-screening (FCRA) and general marketing targeting with fine-grained geographic precision. The ZIP4-level scoring provided significantly more targeting precision than ZIP5, and the 3-year validation demonstrated temporal stability that gave carriers confidence for production deployment.

## 9. Relevant Skills Demonstrated
- Predictive scorecard development
- Regulatory compliance (FCRA)
- Geographic segmentation (ZIP4/ZIP5)
- Model validation and stability testing
- Insurance domain expertise
- Cross-sell / upsell modeling
- Documentation and deliverable management

## 10. Best-Fit Job Types
- Data Scientist (Insurance/Marketing)
- Risk Modeling Scientist
- Product Data Scientist
- Applied Scientist (Financial Services)

## 11. Resume Bullet Suggestions
- Developed dual-variant prospect survival scorecards (FCRA/non-FCRA) with ZIP4/ZIP5 geographic segmentation, enabling both regulated pre-screening and general marketing applications
- Validated models across 3 years of insurance data (2013–2015), demonstrating temporal stability and ZIP4-level targeting precision significantly exceeding ZIP5-level accuracy
- Delivered comprehensive scorecard documentation spanning 19+ files for client deployment, with appropriate attribute selection for each regulatory context
- Designed geographic segmentation strategy providing fine-grained targeting at ZIP4 level for localized marketing campaigns

## 12. Interview Talking Points
- **Regulatory expertise**: "I built the model in two variants — FCRA-compliant for credit-based pre-screening and non-FCRA for general marketing. The FCRA version required careful attribute selection to meet credit reporting regulations while still providing meaningful risk differentiation."
- **Geographic precision**: "ZIP4-level scoring provided significantly better targeting precision than ZIP5. For localized marketing campaigns, that granularity matters — adjacent ZIP4s can have very different prospect profiles."
- **Temporal validation**: "I validated across 3 years of data to demonstrate temporal stability. Carriers need confidence that the model won't degrade between annual refreshes, so multi-year stability is essential for production deployment."

## 13. Evidence Found
- **pros_sur_model_doc.xlsx** (multiple versions) — Model documentation
- **pros_sur_scorecard_deliverables_*.xlsx** (2013–2014 dates) — Scorecard deliverables
- **non-fcra/** — Non-FCRA model variants subfolder
- **19+ files** — Full development lifecycle documentation
