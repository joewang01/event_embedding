# Premium Model — VIN Matching and Validation

## 1. Executive Summary
Developed Vehicle Identification Number (VIN) matching and validation models for premium rating. The project includes 4 validation presentation iterations (v1–v4) demonstrating iterative model development and stakeholder communication for vehicle verification in insurance premium determination.

## 2. Business / Product Background
VIN matching is essential for accurate insurance premium rating:
- Verifying vehicle identity ensures correct premium calculation
- VIN validation catches data entry errors and fraud
- Monthly update tracking ensures ongoing accuracy
- 4 presentation iterations demonstrate stakeholder engagement

## 3. Data Background
- **VIN matching**: vin_match.xlsx, vin_match_update_month.xlsx
- **Validation presentations**: vin_validation.pptx, vin_validation_v2–v4.pptx (4 versions)

## 4. Technical Approach
- VIN matching algorithms for vehicle verification
- Monthly update monitoring for ongoing accuracy
- Iterative validation (4 versions) with stakeholder review

## 5. My Role and Contribution
- Developed VIN matching and validation models
- Created 4 validation presentations for stakeholders
- Monitored monthly VIN matching updates

## 6. Key Results and Impact
- VIN validation model for premium rating accuracy
- 4 validation iterations demonstrate thorough stakeholder alignment
- Monthly update monitoring ensures ongoing reliability

## 7. Challenges and Solutions
- **Matching Accuracy**: VIN data has entry errors → Built validation algorithms with progressive improvement through 4 iterations

## 8. Job Application Story
- **Situation**: Insurance premium rating accuracy depends critically on correct vehicle identification, but VIN (Vehicle Identification Number) matching across databases is inherently noisy — transcription errors, partial VINs, and format inconsistencies can lead to incorrect vehicle classification and mispriced policies.
- **Task**: I owned the development of VIN matching and validation models, defining the matching algorithm and managing the stakeholder validation process.
- **Action**: I developed VIN matching algorithms that handle partial matches, format variations, and common transcription errors. I monitored monthly update accuracy to detect drift, presented 4 validation iterations to stakeholders, and refined matching logic based on error pattern analysis from production data.
- **Result**: Delivered a VIN validation model ensuring premium rating accuracy with monthly monitoring and stakeholder-validated reliability, reducing vehicle misclassification risk in premium calculations.

## 9. Relevant Skills Demonstrated
- Data matching algorithms, validation methodology, stakeholder communication, insurance domain

## 10. Best-Fit Job Types
- Data Scientist, Data Quality Engineer, Applied Scientist

## 11. Resume Bullet Suggestions
- Developed VIN matching and validation algorithms for insurance premium rating accuracy, handling partial matches, format variations, and transcription errors
- Implemented monthly accuracy monitoring for VIN matching with drift detection, presenting 4 iterative validation reviews to stakeholders
- Reduced vehicle misclassification risk in premium calculations through systematic error pattern analysis and matching logic refinement

## 12. Interview Talking Points
- "VIN matching is deceptively hard — transcription errors, partial VINs, and format inconsistencies are common across insurance databases. I built matching algorithms that handle these edge cases and monitored accuracy monthly to detect drift."
- "Incorrect vehicle identification directly impacts premium accuracy. The 4 validation iterations with stakeholders ensured the matching logic met the reliability thresholds needed for production rating systems."

## 13. Evidence Found
- **vin_match.xlsx, vin_match_update_month.xlsx** — VIN matching data
- **vin_validation_v1–v4.pptx** — 4 validation presentations
