# Future — Futures & Commodities Trading Data

## 1. Executive Summary
Curated and organized a comprehensive historical futures and commodities trading dataset spanning 2005–2019, covering corn, crude oil, VIX, and wheat. Built a research-ready data archive for quantitative trading analysis and backtesting.

## 2. Business / Product Background
Futures market research and quantitative analysis:
- Multiple commodity markets (corn, crude oil, wheat)
- VIX volatility futures
- 14+ years of historical data
- Supporting strategy research and backtesting

## 3. Data Background
- **Instruments**: Corn, crude oil, VIX, wheat futures
- **Period**: 2005–2019 (14 years)
- **Format**: Organized data files per instrument
- **Usage**: Quantitative research and backtesting

## 4. Technical Approach
- Historical futures data collection and organization
- Multi-commodity data standardization
- Time series data archival and management

## 5. My Role and Contribution
- Collected and organized 14 years of futures data across 4 commodity markets
- Built structured data archive for quantitative research

## 6. Key Results and Impact
- Comprehensive research-ready futures dataset (2005–2019)
- Multi-commodity coverage enabling cross-market analysis
- Foundation for quantitative trading strategy development

## 7. Challenges and Solutions
- **Data Quality**: Historical data from multiple sources → Standardized and cleaned for consistency

## 8. Job Application Story
- **Situation**: Quantitative futures analysis and strategy backtesting required comprehensive, cleaned historical data across multiple commodity markets.
- **Task**: I built a multi-commodity data archive spanning 14 years for rigorous research and backtesting.
- **Action**: I collected, cleaned, and organized historical futures data for corn, crude oil, VIX, and wheat from 2005–2019, ensuring consistent formatting and handling of contract rollovers for continuous time series analysis.
- **Result**: Delivered a research-ready data archive enabling quantitative strategy research across four commodity markets over 14 years, demonstrating data engineering discipline applied to financial time series.

## 9. Relevant Skills Demonstrated
- Data engineering, quantitative finance, time series data management, financial data curation

## 10. Best-Fit Job Types
- Quantitative Analyst, Data Engineer (Finance), Financial Research Analyst

## 11. Resume Bullet Suggestions
- Curated 14-year historical futures dataset (corn, crude, VIX, wheat) for quantitative research and multi-commodity trading strategy analysis
- Designed data pipeline handling contract rollovers, missing data, and format normalization for continuous time series analysis
- Applied data engineering discipline to financial data curation, enabling reproducible quantitative research across commodity markets

## 12. Interview Talking Points
- "I built a comprehensive 14-year futures data archive across four commodity markets for quantitative trading research."
- "Clean financial data is harder than it looks — contract rollovers, missing data handling, and format normalization are all data engineering challenges that mirror production data pipeline work."

## 13. Evidence Found
- Historical data files for corn, crude oil, VIX, and wheat futures spanning 2005–2019
