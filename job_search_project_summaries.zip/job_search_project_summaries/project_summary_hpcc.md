# HPCC — Commercial Insurance ECL Development

## 1. Executive Summary
Developed ECL (Enterprise Control Language) scripts on the HPCC Systems platform for commercial insurance data processing. Focused on CLUE (Comprehensive Loss Underwriting Exchange) and MVR (Motor Vehicle Record) claims data integration for commercial lines.

## 2. Business / Product Background
Commercial insurance requires specialized data processing:
- CLUE data integration for loss history
- MVR claims processing for commercial fleet/driver management
- Automated ECL pipelines on HPCC distributed computing platform
- Supporting commercial insurance underwriting decisions

## 3. Data Background
- **Data Sources**: CLUE loss history, MVR claims records
- **Platform**: HPCC Systems (Thor/Roxie clusters)
- **Domain**: Commercial insurance lines

## 4. Technical Approach
- ECL programming on HPCC distributed platform
- CLUE data extraction and processing
- MVR claims record integration
- ETL pipelines for commercial insurance data

## 5. My Role and Contribution
- Developed ECL scripts for commercial insurance data processing
- Built CLUE and MVR data integration pipelines
- Conducted data validation and quality analysis

## 6. Key Results and Impact
- Automated commercial insurance data pipelines on HPCC
- Integrated CLUE and MVR data for underwriting support
- Scalable ECL-based data processing workflows

## 7. Challenges and Solutions
- **Data Integration**: Merging CLUE + MVR for commercial lines → Built ECL join/transform pipelines

## 8. Job Application Story
- **Situation**: Commercial insurance underwriting required integrated CLUE loss history and MVR claims data — two critical data sources that needed reliable pipeline processing before they could feed into scoring models.
- **Task**: I developed the ECL pipelines on HPCC to process and integrate these data sources for commercial auto underwriting.
- **Action**: I built scalable ECL scripts for data extraction, transformation, and integration of CLUE and MVR records, ensuring data quality standards consistent with production personal auto products and handling the commercial-specific schema requirements.
- **Result**: Delivered automated data pipelines supporting commercial insurance underwriting with integrated loss and driving history, extending LexisNexis's data processing infrastructure from personal to commercial auto lines.

## 9. Relevant Skills Demonstrated
- ECL programming, HPCC Systems, ETL pipelines, big data processing, insurance data integration

## 10. Best-Fit Job Types
- Data Engineer, Big Data Developer, Insurance Data Scientist

## 11. Resume Bullet Suggestions
- Built ECL pipelines on HPCC Systems integrating CLUE loss history and MVR claims data for commercial insurance underwriting
- Extended personal auto data processing infrastructure to commercial lines, handling commercial-specific schema requirements
- Ensured data quality standards for commercial MVR pipeline consistent with production personal auto products

## 12. Interview Talking Points
- "I developed distributed ECL pipelines on HPCC for commercial insurance, integrating CLUE and MVR data sources with consistent quality standards."
- "Extending from personal auto to commercial required handling different schema patterns while maintaining the same data quality standards."

## 13. Evidence Found
- ECL scripts for CLUE and MVR data processing on HPCC platform, focused on commercial insurance lines
