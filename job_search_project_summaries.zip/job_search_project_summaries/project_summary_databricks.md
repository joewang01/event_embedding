# Databricks — Workspace Configuration & Embedding Development

## 1. Executive Summary
Established Databricks workspace configuration and developed auto insurance embedding models using Windows Subsystem for Linux (WSL). Includes workspace setup, asset bundles (databricks.yml), and ML embedding work for insurance feature engineering.

## 2. Business / Product Background
Databricks platform adoption for insurance analytics:
- Workspace configuration and CI/CD setup
- Asset bundle management (databricks.yml)
- ML embedding development for auto insurance features
- WSL-based development environment for Databricks workflows

## 3. Data Background
- **Platform**: Databricks (Azure/AWS)
- **Config**: databricks.yml asset bundles
- **ML Work**: Auto insurance embedding models on WSL
- **Integration**: Workspace-level configuration and deployment

## 4. Technical Approach
- Databricks workspace setup and configuration
- Asset bundle management via databricks.yml
- Embedding model development on WSL
- Integration with auto insurance data pipelines

## 5. My Role and Contribution
- Configured Databricks workspace and asset bundles
- Developed auto insurance embedding models
- Set up WSL-based development environment

## 6. Key Results and Impact
- Functional Databricks workspace with CI/CD configuration
- Embedding models for auto insurance feature engineering
- Streamlined development workflow via WSL integration

## 7. Challenges and Solutions
- **Environment**: WSL + Databricks integration → Configured databricks.yml for seamless deployment

## 8. Job Application Story
- **Situation**: The data science team was migrating ML workflows from local environments to Databricks, requiring workspace configuration, CI/CD integration via asset bundles, and a working development pipeline for embedding models — foundational infrastructure that all subsequent ML projects would depend on.
- **Task**: I led the Databricks environment setup and developed the first embedding model pipeline as a proof-of-concept for the team's ML infrastructure.
- **Action**: I configured the Databricks workspace with asset bundles (databricks.yml) for CI/CD integration, set up WSL-based development environments for local experimentation, and built auto insurance embedding models as the initial ML workload. This established the infrastructure patterns — Delta tables, Unity Catalog, asset bundle deployment — that all subsequent modeling projects (EV pricing, violation embeddings) would follow.
- **Result**: Delivered a fully configured Databricks ML environment with CI/CD pipeline and working embedding models, establishing the infrastructure foundation that the team's subsequent projects (EV loss cost modeling, Hierarchical Transformer training) were built upon.

## 9. Relevant Skills Demonstrated
- Databricks, MLOps, embeddings, CI/CD, WSL, Python, ML engineering, insurance analytics

## 10. Best-Fit Job Types
- ML Engineer, Data Engineer (Databricks), MLOps Engineer

## 11. Resume Bullet Suggestions
- Led Databricks workspace setup with CI/CD asset bundles, Delta tables, and Unity Catalog configuration, establishing the ML infrastructure foundation for the team's subsequent production modeling projects
- Developed auto insurance embedding models as the initial ML workload on Databricks, proving out the platform's capabilities for deep learning and distributed training
- Configured WSL-based development environments enabling local experimentation with Databricks-deployed models, accelerating the team's ML development workflow

## 12. Interview Talking Points
- "I set up our team's Databricks ML infrastructure — asset bundles for CI/CD, Unity Catalog for data governance, Delta tables for reliable data storage. This foundation was critical because every subsequent ML project built on these patterns."
- "The embedding model I developed was the proof-of-concept that validated Databricks as our ML platform, leading to its adoption for EV pricing, violation embedding training, and other production workloads."

## 13. Evidence Found
- databricks.yml configuration, auto_embedding_wsl directory with ML embedding work
