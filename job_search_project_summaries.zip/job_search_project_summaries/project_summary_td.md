# TD — TD Insurance Analytics Work

## 1. Executive Summary
Developed analytics work for TD Insurance, including Linux scripts, SAS-based common work, and data processing utilities. This represents client-facing insurance analytics supporting TD Insurance products and services.

## 2. Business / Product Background
TD Insurance is a major Canadian insurance provider:
- Client-facing analytics for TD Insurance products
- SAS-based modeling and data processing
- Linux server-based workflows
- Supporting insurance product development and pricing

## 3. Data Background
- **Client**: TD Insurance
- **Tools**: SAS, Linux scripts
- **Content**: Common work scripts and temp files

## 4. Technical Approach
- SAS-based analytics and data processing
- Linux server scripting for automation
- Insurance product analytics workflows

## 5. My Role and Contribution
- Developed analytics for TD Insurance
- Built SAS and Linux automation scripts
- Processed insurance data for client deliverables

## 6. Key Results and Impact
- Client deliverables for TD Insurance
- Automated analytics workflows
- SAS-based insurance analytics

## 7. Challenges and Solutions
- **Platform**: SAS + Linux environment → Built portable scripts for cross-platform deployment

## 8. Job Application Story
- **Situation**: TD Insurance, a major Canadian carrier, needed analytics support for product development and pricing decisions.
- **Task**: I developed SAS-based analytics and Linux automation for TD Insurance data processing and reporting.
- **Action**: I built scripts for data processing, model development support, and automated reporting, delivering client-facing analytics that informed TD's product and pricing strategies.
- **Result**: Delivered client analytics enabling TD Insurance product and pricing decisions, demonstrating the ability to serve major carrier clients with tailored analytical solutions.

## 9. Relevant Skills Demonstrated
- SAS, Linux scripting, insurance analytics, client delivery, data processing

## 10. Best-Fit Job Types
- Data Scientist (Insurance), SAS Developer, Analytics Consultant

## 11. Resume Bullet Suggestions
- Developed SAS-based analytics and Linux automation scripts for TD Insurance, supporting product development and pricing decisions
- Delivered client-facing analytics for a major Canadian carrier, informing product and pricing strategies
- Built automated reporting pipelines using SAS and Linux shell scripting for insurance data processing

## 12. Interview Talking Points
- "I delivered insurance analytics for TD Insurance using SAS and Linux, supporting their product and pricing strategies."
- "TD is a major Canadian carrier, and the engagement required tailoring analytics to their specific market and product needs."

## 13. Evidence Found
- Linux scripts, SAS common work files, and data processing utilities for TD Insurance analytics
