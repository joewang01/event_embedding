# ScoreCard — Attract 3.0 Scoring Model

## 1. Executive Summary
Developed the Attract 3.0 scorecard model for insurance prospect scoring, converting complex model outputs into interpretable scorecards for business users. The scorecard approach enables transparent, auditable scoring with clear factor contributions.

## 2. Business / Product Background
The Attract model scores insurance prospects for likelihood of conversion:
- Third major version (3.0) indicating significant evolution
- Scorecard format for transparency and regulatory compliance
- Factor-based scoring for business user interpretation
- Prospect prioritization for marketing campaigns

## 3. Data Background
- **Model**: Attract 3.0 (insurance prospect scoring)
- **Format**: Scorecard-based model output
- **Usage**: Prospect ranking and marketing targeting

## 4. Technical Approach
- Scorecard model development (WOE/IV or points-based)
- Model factor selection and weight assignment
- Score binning and calibration
- Validation and lift analysis

## 5. My Role and Contribution
- Developed Attract 3.0 scorecard model
- Defined scoring factors and point assignments
- Validated scorecard performance across segments

## 6. Key Results and Impact
- Attract 3.0 scorecard deployed for prospect scoring
- Transparent, interpretable model for business stakeholders
- Effective prospect prioritization for marketing

## 7. Challenges and Solutions
- **Interpretability**: Complex model → Scorecard format for transparency
- **Performance**: Maintaining accuracy in simplified format → Careful feature selection and calibration

## 8. Job Application Story
- **Situation**: Insurance prospect scoring required a transparent, interpretable model for marketing prioritization — complex ML models wouldn't work because business stakeholders needed to understand and audit the scoring logic.
- **Task**: I developed the Attract 3.0 scorecard model with clear factor contributions that balanced predictive power with interpretability.
- **Action**: I selected scoring factors, assigned point weights, calibrated score bins, and validated lift across segments to ensure the scorecard performed well across diverse populations.
- **Result**: Delivered the Attract 3.0 scorecard enabling transparent prospect prioritization with auditable scoring factors — a model that business stakeholders could understand, trust, and explain to regulators.

## 9. Relevant Skills Demonstrated
- Scorecard modeling, WOE/IV analysis, model interpretability, insurance analytics, prospect scoring

## 10. Best-Fit Job Types
- Data Scientist (Insurance), Credit/Risk Modeler, Decision Science Analyst

## 11. Resume Bullet Suggestions
- Developed Attract 3.0 scorecard model for insurance prospect scoring with transparent, interpretable factor-based ranking for marketing prioritization
- Calibrated score bins and validated lift across population segments, ensuring consistent performance for diverse insurance markets
- Balanced predictive power with regulatory interpretability, delivering a model business stakeholders could audit and explain

## 12. Interview Talking Points
- "I built the Attract 3.0 scorecard, converting complex models into transparent, auditable scoring for business stakeholders."
- "In regulated industries, model interpretability isn't optional — scorecards provide the transparency that regulators and business stakeholders require while maintaining predictive power."

## 13. Evidence Found
- Scorecard model files and documentation for Attract 3.0 insurance prospect scoring model
