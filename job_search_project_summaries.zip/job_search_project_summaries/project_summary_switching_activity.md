# Switching Activity — Customer Churn Model Planning

## 1. Executive Summary
Planned and documented a comprehensive insurance customer switching/churn model solution. The project includes multiple planning document iterations (October 2013) and a production implementation plan, designed to detect and prevent customer switches to competitors through trigger-based campaign integration.

## 2. Business / Product Background
Customer switching between insurance carriers represents significant revenue loss. The Switching Activity model:
- Detects signals indicating customers are likely to switch carriers
- Enables proactive retention campaigns to at-risk customers
- Integrates with trigger-based campaign execution systems
- Provides actionable switching probability scores for carrier clients

## 3. Data Background
- **Planning documents**: Switching Activity model Plan.docx, multiple October 2013 versions
- **Production plan**: Production plan of Switching Activity model solution with.docx
- **Campaign integration**: trigger_dev.xlsx — trigger development data for campaign execution

## 4. Technical Approach
- **Churn/switching modeling**: Predicting carrier switching probability
- **Trigger-based campaigns**: Integration with campaign trigger systems for proactive outreach
- **Production planning**: End-to-end solution architecture from model to campaign execution
- **Iterative planning**: 3+ document versions refining the approach

## 5. My Role and Contribution
- Designed the switching activity model solution architecture
- Authored planning documents across multiple iterations
- Developed production implementation plan
- Integrated model output with trigger campaign execution

## 6. Key Results and Impact
- Comprehensive model solution plan for carrier switching detection
- Production-ready implementation design integrating with trigger campaigns
- Documented architecture enabling team implementation

## 7. Challenges and Solutions
- **Signal Complexity**: Many factors drive customer switching → Designed comprehensive feature set based on insurance domain knowledge
- **Campaign Integration**: Model scores need to translate to actionable campaigns → Built trigger-based campaign integration architecture

## 8. Job Application Story
- **Situation**: Insurance carriers were losing customers to competitors without early warning signals — by the time a policy cancelled, retention efforts came too late.
- **Task**: I designed the complete switching activity model solution from detection through automated campaign execution.
- **Action**: I authored comprehensive model planning documents through 3+ iterations, designed the production implementation architecture, and integrated the solution with trigger-based campaign systems for automated retention interventions.
- **Result**: Delivered a complete switching detection solution design enabling carriers to proactively identify and retain at-risk customers through automated trigger campaigns — shifting retention from reactive to proactive.

## 9. Relevant Skills Demonstrated
- Churn/retention modeling
- Solution architecture design
- Technical documentation
- Campaign analytics integration
- Insurance domain expertise
- Product thinking

## 10. Best-Fit Job Types
- Data Scientist (Insurance/Marketing)
- Product Data Scientist
- Analytics Lead

## 11. Resume Bullet Suggestions
- Designed customer switching detection model solution with trigger-based campaign integration for proactive carrier retention
- Authored comprehensive model planning documentation through 3+ iterations with production implementation architecture

## 12. Interview Talking Points
- "I designed a switching activity model that detects when insurance customers are likely to switch carriers, integrated with trigger-based campaigns for proactive retention."
- "The key insight was shifting from reactive retention — responding after cancellation — to proactive detection. Automated triggers mean the retention campaign fires before the customer calls to cancel."

## 13. Evidence Found
- **Switching Activity model Plan.docx** — Primary planning document
- **Switching Activity model Plan 201310*.docx** (3 versions) — October 2013 iterations
- **Production plan of Switching Activity model solution with.docx** — Production implementation plan
- **trigger_dev.xlsx** — Trigger development data
