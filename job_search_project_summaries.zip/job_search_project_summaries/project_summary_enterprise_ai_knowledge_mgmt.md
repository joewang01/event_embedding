# Enterprise AI Knowledge Management — Copilot-Configured Agents for Semantic Search

## 1. Executive Summary
Participated in the strategic planning and architecture design for an enterprise-wide AI knowledge management system using Microsoft Copilot-configured Agents to enable semantic search across insurance team repositories. The initiative connects team-specific SharePoint sites to a centralized Insurance Hub, with AI agents crawling knowledge bases for FAQ retrieval, document discovery, and contextual information access — replacing manual searches through scattered documentation.

## 2. Business / Product Background
Insurance analytics teams at LexisNexis generate substantial institutional knowledge across SharePoint sites, Confluence pages, and shared drives — but discovering relevant content requires knowing where to look and what to search for. New team members, cross-functional collaborators, and leadership frequently struggle to find existing documentation, established methodologies, or past project learnings.

The Content Discovery & Knowledge Sharing initiative uses Microsoft Copilot-configured Agents to solve this by providing conversational, semantic search capabilities over team knowledge repositories. Instead of keyword-based SharePoint searches, users can ask natural language questions and receive contextually relevant answers with source links.

## 3. Data Background
- **Knowledge sources**: Team-specific SharePoint sites across Insurance analytics organization
- **Central hub**: Insurance Hub SharePoint site serving as the aggregation point
- **Content types**: Project documentation, methodology guides, meeting notes, SOPs, FAQ documents, analytical reports
- **Index scope**: Multiple team repositories linked to the central hub for cross-team discovery

## 4. Technical Approach
- **Agent framework**: Microsoft Copilot-configured Agents (M365 Copilot)
- **Architecture**: 
  - Each insurance analytics team maintains a SharePoint site with structured knowledge content
  - Team sites are linked to the centralized Insurance Hub
  - Copilot Agents are configured to perform semantic searches across the connected repositories
  - Agents crawl indexed content and return contextually relevant results with source references
- **Search paradigm**: Semantic search (embedding-based similarity) rather than keyword matching — enabling users to find content even when they don't know the exact terminology
- **Deployment**: M365 Copilot platform with enterprise security and access controls

## 5. My Role and Contribution
- **Strategic planning group member**: Part of the leadership team defining the Content Discovery & Knowledge Sharing approach
- **Architecture input**: Contributed to decisions on how to structure SharePoint sites for optimal agent crawling and semantic retrieval
- **Use case definition**: Helped identify high-value knowledge discovery scenarios (FAQ retrieval, methodology lookup, cross-team project discovery)
- **Cross-functional alignment**: Worked with Salman Anwar, Christa Reynolds, Victor Bayus, Brad Foil, Brian Keller, and Mollie Quinnelly to define the implementation strategy

## 6. Key Results and Impact
- Defined the architecture for enterprise-scale semantic knowledge discovery using Copilot Agents
- Aligned multiple insurance analytics teams on a common knowledge management approach
- Established patterns for AI-powered content discovery that can scale across the broader RELX organization
- Positioned the insurance analytics organization as an early adopter of Copilot Agent technology within the enterprise

## 7. Challenges and Solutions
- **Knowledge fragmentation**: Documentation spread across dozens of SharePoint sites with inconsistent structure → Designed a hub-and-spoke architecture linking team sites to a central Insurance Hub
- **Content quality for semantic search**: Not all existing documentation is structured for AI retrieval → Defined content organization guidelines for teams to improve Agent crawling effectiveness
- **Adoption across teams**: Different teams have different documentation practices → Engaged team leads through the strategic planning group to build consensus on the approach

## 8. Job Application Story
- **Situation**: Insurance analytics teams at LexisNexis accumulated years of institutional knowledge across scattered SharePoint sites, Confluence pages, and shared drives. Finding relevant documentation required knowing where to look, and new team members or cross-functional collaborators frequently couldn't locate existing methodologies, past results, or established procedures.
- **Task**: As Principal Data Scientist I and member of the strategic planning group, I contributed to designing an AI-powered knowledge management system using Microsoft Copilot-configured Agents for semantic search across team repositories.
- **Action**: I participated in the Content Discovery & Knowledge Sharing initiative, helping define the hub-and-spoke architecture (team SharePoint sites linked to a centralized Insurance Hub), identifying high-value knowledge discovery use cases, and aligning multiple team leads on the implementation approach. I worked with a cross-functional group of six leaders to define how Copilot Agents would crawl, index, and retrieve content using semantic search rather than keyword matching.
- **Result**: Delivered the architectural blueprint for enterprise-scale AI knowledge management using Copilot Agents, positioning the insurance analytics organization as an early adopter of this technology within RELX. The approach enables natural language queries against team knowledge bases with referenced, contextual results — establishing patterns for broader organizational adoption.

## 9. Relevant Skills Demonstrated
- Agentic AI / Copilot Agent configuration
- Enterprise AI strategy and architecture
- Semantic search and knowledge management
- Microsoft 365 Copilot platform
- Cross-functional leadership and stakeholder alignment
- SharePoint information architecture
- Change management and technology adoption

## 10. Source
This project was identified from email evidence (Salman Anwar email on Content Discovery & Knowledge Sharing initiative) — not from project folder artifacts. The email threads confirm active participation in the strategic planning group defining the Copilot Agent approach for insurance analytics knowledge management.
