# Life Attrition — Life Insurance Attrition Modeling

## 1. Executive Summary
Developed life insurance attrition analysis with profiling of hit vs. no-hit segments, examining factors like address stability and SSN-address linking scores that drive customer attrition. The project spans two related folders, covering attrition model reporting and attribute scoring analysis.

## 2. Business / Product Background
Life insurance attrition (policy lapse/surrender) is a critical business metric:
- Identifying factors driving attrition enables retention strategies
- Hit/no-hit analysis compares data-enriched vs. non-enriched populations
- Address stability and identity linking indicate customer stability

## 3. Data Background
- **Model report**: Life_insurance_attrition_model_report.xls
- **Comparison data**: comp.csv, life_attrition_nohit_comp.xlsx
- **Profile analysis**: profile.xlsx
- **Attributes**: Address stability scores, SSN-address linking scores

## 4. Technical Approach
- Attrition modeling for life insurance policy lapse prediction
- Hit/no-hit segmentation analysis comparing enriched populations
- Attribute scoring (address stability, SSN-address linking)
- Profile analysis for factor identification

## 5. My Role and Contribution
- Built life insurance attrition model
- Conducted hit/no-hit comparison analysis
- Profiled key attrition drivers (address stability, SSN linking)

## 6. Key Results and Impact
- Identified key factors driving life insurance attrition
- Hit/no-hit analysis quantifies data enrichment value
- Profile insights support retention strategy development

## 7. Challenges and Solutions
- **Multiple Attrition Drivers**: Many factors influence life insurance lapse → Used profiling and hit/no-hit analysis to isolate key drivers

## 8. Job Application Story
- **Situation**: Life insurance policy lapse represented significant revenue erosion, but the business lacked data-driven understanding of what distinguishes retained vs. lapsed policyholders.
- **Task**: I built attrition models and conducted factor analysis to identify the key drivers of policy lapse, enabling targeted retention strategies.
- **Action**: I conducted hit/no-hit segmentation analysis, profiled address stability and SSN-address linking as attrition indicators, and built the attrition prediction model using LexisNexis public records data to surface signals invisible in traditional insurance data.
- **Result**: Delivered attrition factor analysis identifying key drivers of life insurance policy lapse — notably that address instability and weak identity linking were strong lapse predictors — enabling targeted retention campaigns for at-risk policyholders.

## 9. Relevant Skills Demonstrated
- Attrition/churn modeling, segmentation analysis, profile analytics, life insurance domain

## 10. Best-Fit Job Types
- Data Scientist (Insurance/Risk), Applied Scientist

## 11. Resume Bullet Suggestions
- Developed life insurance attrition model with hit/no-hit segmentation identifying address stability and identity linking as key retention drivers
- Leveraged LexisNexis public records data to surface attrition signals invisible in traditional insurance data
- Delivered factor analysis enabling targeted retention campaigns for at-risk policyholders, reducing lapse-driven revenue erosion

## 12. Interview Talking Points
- "I analyzed life insurance attrition by comparing hit/no-hit segments and found that address stability and SSN-address linking were strong predictors of policy lapse — signals from public records data that traditional insurance data misses."
- "The insight was that attrition isn't just about premium pricing — identity stability signals from LexisNexis data can predict lapse before it happens."

## 13. Evidence Found
- **Life_insurance_attrition_model_report.xls** — Attrition model report
- **comp.csv, life_attrition_nohit_comp.xlsx** — Hit/no-hit comparison
- **profile.xlsx** — Profile analysis
