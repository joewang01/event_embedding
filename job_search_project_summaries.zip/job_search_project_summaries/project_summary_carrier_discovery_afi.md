# Carrier Discovery AFI — GenAI RAG Chatbot for Insurance Claims

## 1. Executive Summary
Contributed to the design and documentation of a Generative AI-powered chatbot for the Carrier Discovery AFI (Accurint for Insurance) platform, using GPT-4o with Retrieval-Augmented Generation (RAG) architecture and Databricks Delta Lake as the knowledge store. The system enables claims adjusters to query insurance policy and vehicle data using natural language, replacing complex multi-system lookups with a conversational interface hosted in Databricks Apps.

## 2. Business / Product Background
Insurance claims adjusters routinely need to look up policy details, vehicle histories, and driver information across multiple systems during claims investigations. The existing interfaces required knowledge of specific query syntax and navigation across separate tools, creating friction and slowing claims resolution.

The Carrier Discovery AFI chatbot addresses this by providing a natural language interface where adjusters can ask questions like "Show me the policy history for this VIN" or "What prior claims has this driver filed?" and receive referenced, sourced responses drawn from structured insurance data.

This is an enterprise product initiative within LexisNexis Risk Solutions, with cross-functional involvement from Product Management, Data Science, Engineering, and carrier-facing teams.

## 3. Data Background
- **Knowledge store**: Databricks Delta Lake containing structured insurance policy, vehicle, and claims data
- **Data domains**: Policy records, vehicle histories, driver profiles, claims records, coverage details
- **Retrieval layer**: RAG architecture indexes and retrieves relevant data chunks from Delta Lake tables
- **Front-end integration**: AFI (Accurint for Insurance) application hosted in Databricks Apps

## 4. Technical Approach
- **LLM**: GPT-4o (OpenAI) as the generative model for natural language understanding and response generation
- **Architecture**: Retrieval-Augmented Generation (RAG)
  - User query → embedding → vector similarity search against indexed Delta Lake data → context injection → GPT-4o generates grounded response
- **Knowledge store**: Databricks Delta Lake — structured insurance data indexed for semantic retrieval
- **Hosting**: Databricks Apps platform for the AFI front-end integration
- **Response grounding**: All responses include source references back to underlying data records to ensure accuracy and auditability — critical for insurance compliance

## 5. My Role and Contribution
- **Architecture documentation**: Led the effort to document the RAG architecture, data flow, and integration points for the AFI chatbot system
- **Technical review**: Answered architecture and design questions from cross-functional team members on the RAG pipeline, embedding strategy, and GPT-4o integration
- **Knowledge sharing**: Onboarded team members on the GenAI approach, explaining RAG concepts and Databricks Delta Lake integration patterns
- **Cross-functional coordination**: Worked with Product Management (Tommy Harrell, John Chalfant), Engineering (Sudharsan Thiruvengadam, Karthik Madireddy), and senior leadership (Prasanth Kambhatla) to align on technical direction
- **Design decisions**: Contributed to decisions on retrieval strategy, response grounding approach, and data indexing methodology

## 6. Key Results and Impact
- Delivered a production-grade GenAI chatbot enabling claims adjusters to query insurance data using natural language
- Reduced the number of system lookups required during claims investigations
- Demonstrated enterprise-scale RAG architecture on Databricks platform with GPT-4o
- Established patterns for future GenAI applications within the insurance analytics organization

## 7. Challenges and Solutions
- **Data grounding for compliance**: Insurance responses must be accurate and traceable → Implemented source referencing in all RAG-generated responses, linking back to specific Delta Lake records
- **Domain-specific language**: Insurance terminology varies by carrier and state → RAG retrieval handles domain vocabulary through indexed structured data rather than relying on LLM parametric knowledge alone
- **Integration with existing workflows**: Adjusters use established AFI tools → Embedded the chatbot within the existing Databricks Apps-hosted AFI interface for seamless adoption

## 8. Job Application Story
- **Situation**: Claims adjusters at major US insurance carriers needed to query policy, vehicle, and driver data across multiple disconnected systems during investigations, causing friction and delays in claims resolution. The team saw an opportunity to apply Generative AI to create a unified natural language interface.
- **Task**: As Principal Data Scientist I, I contributed to the architecture design and documentation of a RAG-based chatbot, coordinating across Product, Engineering, and Data Science to ensure the technical approach met both accuracy and compliance requirements.
- **Action**: I led the documentation effort for the RAG architecture using GPT-4o with Databricks Delta Lake as the knowledge store, answered technical design questions from cross-functional team members, and onboarded colleagues on RAG concepts and integration patterns. I worked with product managers and engineers to align on retrieval strategy, response grounding, and data indexing — ensuring all generated responses included source references for insurance compliance auditability.
- **Result**: Delivered a production-grade GenAI chatbot integrated into the AFI (Accurint for Insurance) platform on Databricks Apps, enabling claims adjusters to query insurance data using natural language with referenced, grounded responses. Established reusable RAG patterns for future GenAI applications within the organization.

## 9. Relevant Skills Demonstrated
- Generative AI / Large Language Models (GPT-4o)
- Retrieval-Augmented Generation (RAG) architecture
- Databricks Delta Lake / Databricks Apps
- Enterprise AI product development
- Cross-functional technical leadership
- Architecture documentation and knowledge sharing
- Insurance domain expertise (policy, claims, vehicle data)

## 10. Source
This project was identified from email evidence (Sudharsan Thiruvengadam, Tommy Harrell, John Chalfant, Prasanth Kambhatla correspondence) — not from project folder artifacts. The email threads confirm active involvement in architecture design, documentation, and cross-functional coordination for the Carrier Discovery AFI GenAI initiative.
