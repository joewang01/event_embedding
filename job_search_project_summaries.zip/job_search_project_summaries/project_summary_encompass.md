# Encompass — Customer Lookalike Modeling

## 1. Executive Summary
Developed a comprehensive customer lookalike model for Encompass Insurance with national and California-specific variants. The project progressed through multiple iterations (April–July), with performance validation presentations and profile analytics demonstrating model effectiveness for customer acquisition targeting.

## 2. Business / Product Background
Encompass Insurance (an Allstate subsidiary) needed to identify prospective customers who resemble their best existing customers. The lookalike model enables:
- Targeted customer acquisition campaigns
- Efficient marketing spend allocation
- National and regional (California-specific) audience targeting
- Data-driven prospect scoring for campaign prioritization

## 3. Data Background
- **Model documentation**: encomp_model_doc_*.xlsx (versions from 0411 to 0728) — tracking 4+ months of development
- **Performance data**: encompass_customer_lookalike_Performance_*.pptx — validation presentations
- **National scope**: national_wide_model_doc.xlsx — nationwide model documentation
- **Profile analytics**: profile_raw.xlsx — raw profile data for feature analysis
- **Geographic focus**: California-specific analysis alongside national model

## 4. Technical Approach
- **Lookalike Modeling**: Identifying prospects similar to existing high-value Encompass customers
- **National vs. Regional**: Built both national model and CA-specific variant
- **Iterative Development**: 4+ month development cycle (April–July) with continuous refinement
- **Profile Analytics**: Feature profiling to understand customer characteristics driving model predictions
- **Performance Validation**: Presentation-based validation with carrier stakeholders

## 5. My Role and Contribution
- Built and refined customer lookalike model through 4+ months of iterative development
- Developed both national and California-specific model variants
- Conducted profile analytics to understand key customer characteristics
- Presented performance validation results to Encompass stakeholders
- Managed multi-version model documentation

## 6. Key Results and Impact
- Delivered production-ready lookalike model for Encompass (Allstate subsidiary)
- National and California-specific models enable multi-level targeting precision
- 4+ months of iterative refinement demonstrate rigorous model development process
- Model supports customer acquisition campaign targeting

## 7. Challenges and Solutions
- **National vs. Regional Balance**: California market differs from national trends → Built separate CA-specific model alongside national model
- **Iterative Stakeholder Alignment**: Multiple refinement cycles needed → Maintained clear version documentation (0411–0728) with performance presentations at each stage
- **Profile Complexity**: Many potential features for lookalike definition → Conducted raw profile analysis to identify strongest signals

## 8. Job Application Story
- **Situation**: Encompass Insurance (Allstate subsidiary) needed to identify and target prospective customers who resembled their best existing policyholders, but their marketing was based on broad demographic targeting rather than data-driven lookalike modeling.
- **Task**: I owned the development of a customer lookalike model with both national and California-specific variants, managing the iterative development process and carrier stakeholder relationship.
- **Action**: I built the lookalike model through 4+ months of iterative development (April–July), conducting profile analytics to identify the key customer characteristics that differentiated high-value policyholders. I developed national and California-specific model variants to account for the state's unique market dynamics, presented performance validation to carrier stakeholders at each iteration, and refined the model based on their domain expertise and campaign requirements.
- **Result**: Delivered a multi-level lookalike targeting system that enabled Encompass to shift from broad demographic marketing to precision targeting — prioritizing high-potential prospects who matched the profile of their most profitable policyholders across both national and state-specific campaigns.

## 9. Relevant Skills Demonstrated
- Lookalike/similarity modeling
- Customer segmentation
- Profile analytics
- Model development and iteration
- National/regional model customization
- Stakeholder communication
- Insurance domain expertise

## 10. Best-Fit Job Types
- Product Data Scientist
- Data Scientist (Marketing/Insurance)
- Analytics Lead
- Customer Analytics Scientist

## 11. Resume Bullet Suggestions
- Developed customer lookalike model for Encompass Insurance (Allstate subsidiary) with national and California-specific variants, enabling precision prospect targeting over broad demographic marketing
- Managed 4+ month iterative development cycle with regular carrier stakeholder presentations, refining model based on domain expertise and campaign requirements
- Built profile analytics pipeline identifying key characteristics that differentiate high-value policyholders from general population across geographic segments

## 12. Interview Talking Points
- **Client engagement**: "I managed the full carrier relationship for this project — building the model, presenting validation at each iteration, and incorporating stakeholder feedback. The 4-month development cycle included multiple refinement rounds driven by the carrier's domain expertise."
- **Geographic customization**: "California has unique insurance market dynamics, so I built separate national and state-specific model variants. The California model captured local competitive patterns that the national model missed, providing significantly better targeting precision for their largest market."
- **Business outcome**: "Encompass shifted from broad demographic marketing to precision lookalike targeting. By identifying prospects who matched the profile of their most profitable policyholders, they could allocate marketing spend more efficiently across campaigns."

## 13. Evidence Found
- **encomp_model_doc_*.xlsx** (versions 0411–0728) — Iterative model documentation
- **encompass_customer_lookalike_Performance_*.pptx** — Performance validation presentations
- **national_wide_model_doc.xlsx** — National model documentation
- **profile_raw.xlsx** — Raw profile analytics data
