# Event Embedding — Hierarchical Transformer for Driver Violation Sequence Modeling

## 1. Executive Summary
Designed and built a production Hierarchical Transformer deep learning system that encodes driver violation/MVR event sequences into 256-dimensional embeddings for insurance loss cost prediction. The project spans from foundational research (19 technical documents evaluating GRU, Transformer, and hybrid architectures) through to a complete PyTorch training pipeline on Databricks with distributed data-parallel (DDP) training, NCCL multi-GPU acceleration, mixed precision (AMP), MLflow experiment tracking, Tweedie loss for insurance severity modeling, and ensemble inference. Two model variants — `RiskModel1017` (attention-based feature interaction) and `RiskModel1217` (MLP-based feature interaction) — process sequences of up to 24 violation events per policyholder across 36/60/84-month windows, outputting both scalar loss cost predictions and reusable embedding vectors.

## 2. Business / Product Background
The insurance industry generates sequences of heterogeneous events per customer: claims, inquiries, policy changes, property assessments. Traditional approaches use hand-crafted aggregate features (e.g., "count of claims in 3 years"). Event embeddings offer several advantages:
- Capture temporal patterns and event ordering that aggregate features miss
- Learn representations that transfer across multiple prediction tasks (policy ownership, risk flags, future events)
- Reduce feature engineering effort for new model development
- Potentially outperform GBDT baselines with enough data

The production system (`ins-dsa-NERD-DB360-embedding-pyspark`) encodes **driver violation/MVR event sequences** — court records, MBSI service records, incidents — into fixed-dimensional vectors that predict insurance loss cost and can be extracted as features for downstream models. Evaluation uses **bottom-to-top ratio** (ratio of bottom-decile to top-decile lift) — a standard insurance model lift metric.

## 3. Data Background
- **Training data**: `auto_embedding.train_sdf_embedding_fullpolicyholders` (Databricks Delta table, Unity Catalog: `insanalytics_prod.auto_embedding`)
- **Test data**: `auto_embedding.test_sdf_embedding_fullpolicyholders`
- **Raw source**: `24441_Vector_Embedding_Research_viols_NB.csv` (pipe-delimited violation records)
- **Vocabulary table**: `auto_embedding.violation_vocab` — categorical→integer ID mappings with frequency
- **Violation windows tested**: 12m, 36m, 60m, 84m (non-renewal policyholders)
- **Target variables**: `loss_cost_co` (coverage-level), `loss_cost_pd` (per-driver)
- **Key columns per violation event**:
  - Categorical (8): `viol_src_st`, `MBSI_SVC_MAJOR_MINOR`, `mbsi_svc_category`, `svc`, `ind_weekend`, `ind_federal_holiday_weekend`, `ind_last_week_of_month`, `ind_last_week_of_quarter`
  - Numerical (1): `incident_seq` (sequence number)
  - Recency (1): `month_diff_asse_dt` (months between assessment date and violation date)
- **Sequence structure**: Per-policyholder `array<struct>` of violation events, sorted oldest→newest, left-padded to max length 24

### Research Data
- **DRV_embedding_sample.xlsx** — Driver embedding sample data for experimentation
- **event_embedding/ (19 markdown docs)** — Comprehensive research documents (Obsidian vault)
- Multi-task targets: Policy ownership flags, risk scores, future event predictions

## 4. Technical Approach
### Model Architecture (`Hierarchical_Transformer.py`)
Two variants sharing the same hierarchical structure:

**`RiskModel1017`** (Attention variant):
- `EmbeddingLevel` → `FeatureMultiheadAttention` → `HistoryEncoder` → Linear head
- Feature interaction via multi-head self-attention over per-feature embeddings

**`RiskModel1217`** (MLP variant):
- `EmbeddingLevel` → `FeatureMLP` → `HistoryEncoder` → Linear head
- Feature interaction via GELU-activated 2-layer MLP with residual connection

**Architecture details**:
- **EmbeddingLevel**: Categorical embeddings (dim = min(50, vocab_size^0.25) heuristic), numeric linear projection, recency linear projection, learned positional embeddings, LayerNorm — all projected to d_model dimensions
- **HistoryEncoder**: Pre-norm TransformerEncoder (batch_first=True) with masked mean pooling over sequence positions
- **Output**: Returns both scalar prediction (loss cost) and 256-dim embedding vector
- **Hyperparameters**: d_model=256, nhead=4, num_layers=6, ff_dim=1024, max_T=24, bias_init=2.0

### Training Pipeline
- **Loss**: Custom `TweedieLoss(p=1.5)` — compound Poisson-Gamma, appropriate for insurance claim data with point mass at zero
- **Class balancing**: 50/50 blend of adaptive inverse-frequency weights and static pos_weight=10 for non-zero claims
- **Optimizer**: AdamW (lr=1e-3, weight_decay=0.01)
- **LR schedule**: Cosine with 10% warmup **or** ReduceLROnPlateau (mode='max', factor=0.5)
- **Gradient clipping**: max_norm=2.0
- **Batch sizes**: train=64, test=1024
- **Epochs**: 3 (typically)
- **Best-model tracking**: Validation bottom_to_top_ratio, persisted via MLflow

### Data Loading (`seq_loader.py` / `seq_loader_DDP.py`)
- **`SparkSequenceIterableDataset`**: Streams Spark DataFrame row-by-row, converts `array<struct>` into fixed-length tensor sequences
- **`ParquetSequenceIterableDataset`**: Reads pre-sharded parquet files directly (bypasses Spark at training time for I/O efficiency)
- **Sequence processing**: Sort events oldest→newest, left-pad with zeros to SEQ_LEN=24, build key_padding_mask for Transformer
- **DDP sharding**: Hash-based on `idl` (driver ID) for deterministic partitioning, or Spark partition-based round-robin

### Distributed Training (DDP)
- **NCCL backend** via `torchrun --standalone --nproc_per_node=N`
- **Mixed precision**: `torch.amp.GradScaler` + `autocast` for memory efficiency
- **All-reduce** loss averaging across ranks
- **Pre-sharding**: Separate parquet files per GPU worker via `DatasetShard_DDP.py`
- **Rank-0-only** MLflow logging to avoid metric duplication

### Advanced Training Variants
- **`Training_steps.py`**: Batch-level EMA of validation metric; if 5-step EMA doesn't improve, reverts to best weights, decays LR, retries same batch (up to 2x). Optional proximal regularization toward best weights.
- **`train_multi_epoch.py`**: Per-epoch adjustable hyperparameters via callback, local `.pt` checkpoints with symlink management, early stopping

### Inference & Ensemble
- **Single model** (`inference.py`): Log-link (exp) or softplus for positive output
- **Ensemble** (`inference_ensemble.py`): Average predictions from 5 models in log-space, then exp()
- **Model weight averaging**: Alternative to prediction-level ensemble

### Evaluation (`gains_utils.py`)
- **`build_gains_table`**: 10-bucket decile gains table (policies, losses, lift index, cumulative lift) via PySpark window functions
- **`bottom_to_top_ratio`**: Primary metric — ratio of bottom-decile to top-decile lift indices
- **`build_gains_outputs`**: Convenience wrapper returning table + cumulative curve + ratio

### Data Preprocessing Pipeline
1. **`Convert_table.py`**: Raw CSV → Delta table (`Embedding_Researc_Viols_7yr`)
2. **`violation_preprocessing.py`**: Date parsing (yyyyMMdd→DATE), DOB normalization, deduplication by (idl, asse_dt)
3. **`build_vocab.py`**: Categorical→integer ID vocabulary with `<PAD>=0`, frequency maps, stored as Hive table
4. **`Performancedata.py`**: Full pipeline — data import, vocab mapping, min-max normalization, aggregation into transaction sequences per (idl, asse_dt)

### Experiment Variants
| Script | Window | Model | Training |
|--------|--------|-------|----------|
| `my_train_script.py` | 36m | RiskModel1217 | Multi-worker partition-parallel |
| `my_train_script_v2.py` | 84m | RiskModel1217 | Single-GPU full |
| `my_train_script_v3.py` | 60m | RiskModel1217 | Single-GPU full |
| `my_train_script_v4.py` | 36m | RiskModel1017 | Single-GPU full |

### DL Diagnostics (`dl_param_monitor.py`)
- `DLParamMonitor`: Comprehensive training diagnostics — parameter/gradient/update L1/L2 norms, zero percentages, EMA smoothed signals, cosine similarity between gradient vectors, Adam optimizer state monitoring, activation sparsity via forward hooks on ReLU/GELU layers — all logged to MLflow

### Research Foundation (19 Documents)
- Multi-task event embeddings, focal loss, GradNorm/PCGrad gradient balancing
- Transformer vs GRU benchmarks (EBES KDD 2025)
- Attention pooling, self-supervised pretraining (CoLES, MLEM)
- Numerical/categorical embedding strategies (PLE, NoisyEmbedding)
- Long-tail handling (AdamAR, FAL, SSE)
- Production deployment at Mastercard, Visa, Booking.com
- Regulatory interpretability (GDPR, EU AI Act)

## 5. My Role and Contribution
- **Designed the Hierarchical Transformer architecture** (`RiskModel1017` and `RiskModel1217`) with categorical/numerical/recency embedding layers, feature-level interaction (attention or MLP), TransformerEncoder sequence processing, and masked mean pooling
- **Implemented custom Tweedie loss** (p=1.5) for compound Poisson-Gamma insurance claim distribution
- **Built full data pipeline**: Raw CSV → Delta table → vocabulary mapping → min-max normalization → transaction sequence aggregation → PyTorch tensor conversion with padding/masking
- **Developed distributed training infrastructure**: DDP via torchrun with NCCL, mixed precision (AMP), hash-based dataset sharding, pre-sharded parquet loading, rank-aware MLflow logging
- **Created advanced training strategies**: Batch-level EMA with weight reversion and LR decay, per-epoch adjustable hyperparameters, proximal regularization toward best weights
- **Built ensemble inference pipeline**: 5-model log-space averaging for robust predictions
- **Designed comprehensive DL diagnostics**: `DLParamMonitor` tracking gradient norms, cosine similarity, Adam optimizer state, and activation sparsity — all logged to MLflow
- **Led research initiative**: Authored 19 detailed technical documents covering the full landscape of event embedding methods
- **Evaluated production architectures**: Systematically compared GRU vs. Transformer with production constraints, analyzing deployments at Mastercard, Visa, Booking.com

## 6. Key Results and Impact
- **Production embedding system**: 256-dimensional driver violation embeddings trained on real insurance data via Hierarchical Transformer
- **Multiple violation window experiments**: 36m, 60m, 84m windows evaluated systematically across both model variants
- **Ensemble improvement**: 5-model ensemble with log-space averaging for more robust loss cost prediction
- **Bottom-to-top ratio metric**: Primary evaluation metric aligning with business needs (lift between best and worst predicted deciles)
- **Dual-output architecture**: Models return both loss cost predictions and reusable 256-dim embedding vectors for downstream model integration
- **Research foundation**: Architecture recommendation (GRU for latency-sensitive, Transformer for interpretability), CoLES pretraining as top self-supervised method
- **Reusable tooling**: Gains chart utilities, vocabulary builder, sequence loader, DL diagnostics — all production-quality reusable components

## 7. Challenges and Solutions
- **Sparse insurance claims**: Most policyholders have zero claims → Tweedie loss (p=1.5) naturally handles point mass at zero; class-balanced weighting blends adaptive inverse-frequency with static pos_weight=10
- **Variable sequence lengths**: Policyholders have 0–24+ violations → Left-padding with zeros + key_padding_mask for Transformer; violation_cnt=0 handled as all-mask
- **Multi-GPU data parallelism**: Spark DataFrames don't natively shard for PyTorch DDP → Built hash-based sharding on `idl` and pre-sharded parquet loading to bypass Spark at training time
- **Training instability**: Deep Transformer with small batches → Gradient clipping (max_norm=2.0), batch-level EMA monitoring with automatic weight reversion and LR decay
- **Production latency**: Transformers need full sequence context → Research identified GRU as alternative; current system focuses on batch scoring
- **Long-tail event types**: Rare violation categories → Vocabulary-based encoding with `<PAD>=0` and frequency-aware construction
- **Experiment tracking at scale**: Multiple windows × 2 models × training variants → MLflow integration with per-epoch model artifacts and comprehensive parameter logging

## 8. Job Application Story
- **Situation**: LexisNexis's insurance analytics products relied entirely on hand-crafted aggregate features (counts, flags, ratios) to represent driver violation histories. These features discarded temporal ordering, event co-occurrence, and sequence-level patterns — an increasingly significant limitation as competitor models grew more sophisticated and carrier clients demanded better predictive lift for loss cost modeling.
- **Task**: As technical lead, I initiated and owned the effort to build our first deep learning system for insurance violation sequence modeling — from surveying the research landscape through architecture design, distributed training infrastructure, and production-grade deployment on Databricks.
- **Action**: I started by authoring 19 research documents surveying state-of-the-art approaches (GRU vs. Transformer, CoLES pretraining, multi-task learning from KDD/NeurIPS/ICLR), then made the strategic decision to build a Hierarchical Transformer architecture. I designed two model variants — `RiskModel1017` (attention-based feature interaction) and `RiskModel1217` (MLP-based) — processing sequences of categorical, numerical, and temporal violation features through a 6-layer TransformerEncoder with masked mean pooling to produce 256-dimensional embeddings. I implemented custom Tweedie loss (p=1.5) for insurance severity, built a full DDP multi-GPU training pipeline (NCCL, mixed precision, hash-based sharding), created 5-model ensemble inference in log-space, and developed a comprehensive DL diagnostics system (gradient norms, cosine similarity, Adam state, activation sparsity) all tracked via MLflow. I mentored team members on deep learning concepts and Transformer architecture, guiding them through the transition from traditional tree-based modeling to neural approaches. The complete data pipeline runs on Databricks — from raw CSV through Delta tables, vocabulary mapping, sequence aggregation, to PyTorch tensor conversion.
- **Result**: Delivered the organization's first production deep learning system for insurance — generating 256-dimensional driver risk embeddings from violation sequences, with systematic experiments across 36/60/84-month windows and two architecture variants. The embeddings are designed to feed into downstream models across multiple insurance products, representing a fundamental paradigm shift from hand-crafted features to learned representations that capture temporal patterns invisible to traditional approaches.

## 9. Relevant Skills Demonstrated
- **Deep Learning**: PyTorch (nn.Module, Transformer, MultiheadAttention, DDP, GradScaler/AMP), custom loss functions, embedding architectures
- **Distributed Training**: NCCL, torchrun, DistributedDataParallel, mixed precision, hash-based sharding
- **ML Research**: Architecture evaluation (GRU vs. Transformer), self-supervised pretraining (CoLES, MLEM), multi-task learning (GradNorm, PCGrad)
- **MLOps**: MLflow (model registry, metric logging, artifact tracking), Databricks (Unity Catalog, Delta tables, GPU clusters)
- **Data Engineering**: PySpark (DataFrames, Delta, Window functions, UDFs), Parquet, PyArrow, vocabulary construction
- **Insurance Domain**: Tweedie regression, loss cost modeling, gains table evaluation, bottom-to-top ratio metric
- **Software Engineering**: Modular utility library (27+ files), DL diagnostics monitoring, ensemble inference
- **Research**: 19 technical documents synthesizing KDD, NeurIPS, ICLR, SIGMOD papers

## 10. Best-Fit Job Types
- **Machine Learning Engineer** — Production deep learning system with distributed training and MLflow deployment
- **Applied Scientist** — Research-to-production pipeline with novel architecture design
- **Staff Data Scientist** — Senior technical leadership spanning research, implementation, and evaluation
- **Deep Learning Engineer** — Custom Transformer architecture, DDP training, mixed precision
- **NLP/Sequence Modeling Scientist** — Temporal event sequence encoding, attention mechanisms, embeddings
- **MLOps Engineer** — MLflow integration, Databricks pipelines, distributed training infrastructure

## 11. Resume Bullet Suggestions
- Led the design and implementation of LexisNexis's first production deep learning system — a Hierarchical Transformer generating 256-dimensional driver violation embeddings for insurance loss cost prediction, representing a paradigm shift from hand-crafted features to learned representations
- Architected two Transformer variants (RiskModel1017/1217) with custom Tweedie loss (p=1.5), class-balanced weighting, and 6-layer TransformerEncoder with masked mean pooling, systematically evaluated across 36/60/84-month violation windows
- Built distributed training infrastructure using PyTorch DDP with NCCL, mixed precision (AMP), hash-based dataset sharding, and pre-sharded parquet loading on Databricks multi-GPU clusters
- Developed 5-model ensemble inference averaging predictions in log-space, with comprehensive evaluation via decile gains tables and bottom-to-top ratio metrics aligned with insurance business needs
- Created end-to-end data pipeline on Databricks: raw violation CSV → Delta tables → vocabulary mapping → min-max normalization → transaction sequence aggregation → padded PyTorch tensors with attention masks
- Authored 19 technical research documents surveying GRU vs. Transformer, self-supervised pretraining (CoLES, MLEM), and multi-task learning — establishing the research foundation and architecture recommendation for the team
- Built comprehensive DL diagnostics system tracking gradient norms, cosine similarity, Adam optimizer state, and activation sparsity via MLflow, enabling systematic debugging of training instability
- Mentored team members on deep learning fundamentals and Transformer architecture, guiding the transition from tree-based modeling to neural sequence approaches

## 12. Interview Talking Points
- **Strategic vision**: "I initiated this project because our insurance models were hitting a ceiling with hand-crafted aggregate features. I surveyed 19 research papers from KDD, NeurIPS, and ICLR, then made the architectural decision to build a Hierarchical Transformer rather than a GRU — the attention mechanism provides better interpretability for regulatory requirements, and the architecture supports multi-task transfer learning for downstream products."
- **Architecture design**: "The Transformer has three processing stages: categorical, numerical, and recency features are embedded and projected to 256 dimensions; a feature interaction layer (attention or MLP) captures cross-feature relationships within each timestep; then a 6-layer TransformerEncoder processes the full violation sequence with masked mean pooling. I built two variants to empirically compare attention-based vs. MLP-based feature interaction."
- **Tweedie loss for insurance**: "Insurance claim data has a point mass at zero and is right-skewed — exactly what Tweedie distribution with p=1.5 models. I implemented a custom PyTorch loss with class-balanced weighting that blends adaptive inverse-frequency weights with static pos_weight=10 for non-zero claims."
- **Distributed training at scale**: "I built the full DDP pipeline — NCCL backend via torchrun, hash-based sharding on driver IDs for deterministic data partitioning, pre-sharded parquet files to bypass Spark during training, and mixed precision for memory efficiency. This cut training time significantly on multi-GPU Databricks clusters."
- **Team leadership**: "This was our team's first deep learning project. I led the research direction, designed the architecture, mentored team members on PyTorch and Transformer concepts, and built reusable tooling (gains chart utilities, vocabulary builder, DL diagnostics) that the team now applies to other modeling work."
- **Paradigm shift**: "This project represents a fundamental shift in how we model insurance risk — from manually engineering counts and flags to learning temporal representations directly from event sequences. The 256-dimensional embeddings capture patterns that were invisible to our tree-based models."

## 13. Evidence Found
- **Production codebase (`ins-dsa-NERD-DB360-embedding-pyspark/`)**: 27 Python files including `Train_Embedding.py` (main orchestrator), `Hierarchical_Transformer.py` (model architecture), `TweedieLoss.py`, `seq_loader.py`/`seq_loader_DDP.py` (data loading), `Training.py`/`Training_DDP.py`/`Training_steps.py` (training loops), `inference.py`/`inference_ensemble.py`, `gains_utils.py`, `build_vocab.py`, `violation_preprocessing.py`, `Performancedata.py`, `dl_param_monitor.py`, 4 training script variants, DDP entry points, dataset sharding utilities
- **Research notes (`event_embedding/`, 19 markdown docs)**: Multi-task learning, class imbalance, sequence encoders, pooling, pretraining (CoLES, MLEM), numerical/categorical embeddings, long-tail handling, feature fusion, interpretability, production deployment analysis
- **`DRV_embedding_sample.xlsx`**: Driver embedding sample data
- **Export CSV**: Experimental results and benchmarking outputs
