# CPS All — Multi-Carrier Competitive Positioning Models

## 1. Executive Summary
Developed competitive positioning and cross-sell/retention models for multiple major insurance carriers including Travelers, Allstate, and State Farm. The project includes conversion and retention validation with geographic segmentation, user manuals for model deployment, and carrier-specific model tuning across the insurance market.

## 2. Business / Product Background
CPS (Competitive Positioning Score) models help carriers understand their market position and optimize targeting:
- Competitive ratio modeling for carrier-to-market comparisons
- Conversion and retention validation across geographies
- Carrier-specific model customization and tuning
- User manuals supporting client deployment

## 3. Data Background
- **Validation data**: 201311_rent_val_br.csv, 201311_rent_val_fcr.csv, 201311_val_br.csv, 201311_val_fcr.csv
- **Carrier data**: travelers_competitive_ratio_model*.xlsx, StateFarm_question*.xlsx, traveler.csv
- **MV counts**: travelers_cps_mv_counts.csv
- **Documentation**: User Manual_*.docx

## 4. Technical Approach
- Competitive ratio modeling with base ratio (BR) and FCR analysis
- Multi-carrier customization (Travelers, Allstate, State Farm)
- Geographic segmentation for localized competitive intelligence
- Retention/conversion validation across time periods
- User manual documentation for client deployment

## 5. My Role and Contribution
- Built competitive positioning models for Travelers, Allstate, and State Farm
- Conducted retention and conversion validation with geographic segmentation
- Created user manuals for client-facing model deployment
- Managed carrier-specific model tuning and customization

## 6. Key Results and Impact
- Multi-carrier competitive positioning models supporting 3+ major carriers
- Geographic segmentation enables localized competitive intelligence
- User manuals enable client self-service model deployment
- Validated conversion and retention metrics across time periods

## 7. Challenges and Solutions
- **Multi-carrier complexity**: Each carrier has different competitive dynamics → Built modular framework with carrier-specific parameters
- **Client enablement**: Carriers need to use models independently → Created comprehensive user manuals

## 8. Job Application Story
- **Situation**: Multiple major insurance carriers — Travelers, Allstate, State Farm — needed competitive positioning models to understand their market standing relative to competitors and optimize marketing strategies by geographic segment.
- **Task**: I owned the development of carrier-specific competitive ratio models with geographic segmentation, managing parallel deliverables across multiple major clients.
- **Action**: I developed carrier-specific competitive positioning models with base ratio and FCR analysis, validated conversion and retention metrics for each carrier, and created user manuals enabling client self-service model deployment. I coordinated parallel model development across 3+ carriers while maintaining consistent methodology.
- **Result**: Delivered multi-carrier competitive intelligence suite supporting 3+ major carriers with validated geographic segmentation and client-facing documentation, enabling each carrier to optimize marketing spend by geographic segment.

## 9. Relevant Skills Demonstrated
- Competitive intelligence modeling
- Multi-carrier analysis
- Geographic segmentation
- Client documentation
- Model validation
- Insurance domain expertise

## 10. Best-Fit Job Types
- Product Data Scientist
- Data Scientist (Insurance)
- Analytics Lead

## 11. Resume Bullet Suggestions
- Developed competitive positioning models for 3+ major carriers (Travelers, Allstate, State Farm) with geographic segmentation
- Created client-facing user manuals enabling carrier self-service model deployment
- Conducted multi-carrier retention and conversion validation with base ratio and FCR analysis

## 12. Interview Talking Points
- "I built competitive positioning models for three major carriers simultaneously, each requiring carrier-specific tuning while maintaining a consistent methodology across all three."
- "Managing parallel client deliverables taught me to design reusable model frameworks — the core methodology was consistent, but each carrier needed custom calibration for their specific market position."

## 13. Evidence Found
- **201311_val_br.csv, 201311_val_fcr.csv** — Base ratio / FCR validation data
- **travelers_competitive_ratio_model*.xlsx** — Travelers carrier model
- **StateFarm_question*.xlsx** — State Farm engagement
- **User Manual_*.docx** — Client documentation
