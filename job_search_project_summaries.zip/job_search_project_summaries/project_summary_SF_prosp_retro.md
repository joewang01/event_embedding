# SF Prosp Retro — Prospect Survival Model Retrospective

## 1. Executive Summary
Conducted retrospective analysis of the Prospect Survival model with sample validation and attrition analysis. The project includes point-in-time testing, model validation presentation, and attri(tion) sample analysis for assessing model accuracy over time.

## 2. Business / Product Background
Retrospective analysis validates whether predictive models performed as expected:
- Point-in-time validation assesses model accuracy on historical data
- Attrition sample analysis measures actual vs. predicted outcomes
- Validation presentations communicate results to stakeholders

## 3. Data Background
- **Retrospective data**: SF_prosp_surv_retro.xlsx
- **Attrition samples**: attri_sample.csv, attri_sample.xlsx
- **Validation**: prospect_survival_model_validation.pptx
- **Reporting**: report.xlsx (multiple versions)

## 4. Technical Approach
- Point-in-time retrospective model validation
- Attrition sample analysis comparing predicted vs. actual outcomes
- Performance presentation for stakeholder communication
- Multi-version reporting for comprehensive analysis

## 5. My Role and Contribution
- Conducted prospect survival model retrospective analysis
- Performed attrition sample validation
- Created validation presentation and reports

## 6. Key Results and Impact
- Retrospective validation confirming model accuracy
- Attrition analysis providing actual vs. predicted comparison
- Stakeholder-ready validation documentation

## 7. Challenges and Solutions
- **Temporal Bias**: Retrospective analysis can be misleading → Used point-in-time methodology ensuring proper validation

## 8. Job Application Story
- **Situation**: The Prospect Survival model needed retrospective validation to confirm its accuracy on historical data — without this validation, stakeholders couldn't trust forward-looking predictions.
- **Task**: I conducted the retrospective analysis with point-in-time methodology and attrition validation.
- **Action**: I performed point-in-time analysis comparing predicted vs. actual attrition, using proper temporal holdout methodology to avoid look-ahead bias, created validation reports, and presented results to stakeholders.
- **Result**: Delivered retrospective validation demonstrating model accuracy with actual outcome comparisons, building stakeholder confidence in the model's forward-looking predictions.

## 9. Relevant Skills Demonstrated
- Model validation, retrospective analysis, attrition modeling, stakeholder communication

## 10. Best-Fit Job Types
- Data Scientist, Applied Scientist, Risk Modeling Scientist

## 11. Resume Bullet Suggestions
- Conducted prospect survival model retrospective validation using point-in-time methodology with attrition sample analysis
- Applied proper temporal holdout methodology to avoid look-ahead bias in model validation
- Presented validation results building stakeholder confidence in forward-looking model predictions

## 12. Interview Talking Points
- "I conducted a retrospective validation of the prospect survival model, using point-in-time methodology to properly compare predicted vs. actual outcomes."
- "Point-in-time validation is critical — without temporal holdout, you get inflated accuracy from look-ahead bias. Proper validation built the stakeholder trust needed for production deployment."

## 13. Evidence Found
- **SF_prosp_surv_retro.xlsx** — Retrospective data
- **attri_sample.csv, attri_sample.xlsx** — Attrition samples
- **prospect_survival_model_validation.pptx** — Validation presentation
- **report.xlsx** — Analysis reports
