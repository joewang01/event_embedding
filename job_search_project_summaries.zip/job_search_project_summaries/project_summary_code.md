# Code — Strawberry Ripeness Classification (Image AI)

## 1. Executive Summary
Developed an image classification project for strawberry ripeness detection using OpenAI API, classifying strawberries as ripe, unripe, or overripe. Jupyter notebooks with organized training image datasets demonstrate computer vision and AI API integration.

## 2. Business / Product Background
Image-based classification using AI APIs:
- Strawberry ripeness classification (ripe, unripe, overripe)
- OpenAI API integration for image analysis
- Practical computer vision application

## 3. Data Background
- **Images**: Categorized into ripe/, unripe/, overripe/ directories
- **Notebooks**: 2 Jupyter notebooks for model development
- **API**: OpenAI API for image classification

## 4. Technical Approach
- Image classification using OpenAI API
- Three-class categorization (ripe, unripe, overripe)
- Jupyter notebook-based development workflow
- Organized image dataset management

## 5. My Role and Contribution
- Designed image classification pipeline
- Integrated OpenAI API for image analysis
- Curated and organized training datasets

## 6. Key Results and Impact
- Working strawberry ripeness classification system
- Demonstrated AI API integration for computer vision
- Organized dataset with three ripeness categories

## 7. Challenges and Solutions
- **Classification Accuracy**: Subtle visual differences → Used AI API for robust feature extraction

## 8. Job Application Story
- **Situation**: Image classification is a foundational AI capability, and I wanted hands-on experience integrating LLM-based vision APIs for practical classification tasks.
- **Task**: I designed and built a multi-class strawberry ripeness classifier as a rapid prototype demonstrating API-based computer vision.
- **Action**: I curated a labeled dataset of ripe/unripe/overripe strawberries, integrated the OpenAI image analysis API, and developed Jupyter notebooks for the end-to-end classification pipeline including image preprocessing, API calls, and result evaluation.
- **Result**: Delivered a working image classification system demonstrating rapid prototyping of AI API integration — the same API integration patterns I applied to production LLM projects at LexisNexis.

## 9. Relevant Skills Demonstrated
- Computer vision, OpenAI API, image classification, Python, Jupyter notebooks, dataset curation

## 10. Best-Fit Job Types
- ML Engineer, Computer Vision Engineer, AI Application Developer

## 11. Resume Bullet Suggestions
- Built multi-class image classification system using OpenAI vision API with curated labeled dataset and end-to-end Jupyter notebook pipeline
- Demonstrated rapid AI prototyping capability from dataset curation through API integration to result evaluation
- Applied API integration patterns from personal projects to production LLM deployments in insurance analytics

## 12. Interview Talking Points
- "I built a multi-class image classifier using OpenAI's vision API as a rapid prototype. The same API integration patterns — prompt engineering, result parsing, error handling — applied directly to production LLM projects."
- "I learn best by building. Personal projects like this let me experiment with new AI APIs quickly, then apply proven patterns to enterprise work."

## 13. Evidence Found
- 2 Jupyter notebooks, 3 organized image directories (ripe, unripe, overripe), OpenAI API integration
