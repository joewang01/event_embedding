# SVC Suspension — NLP-Based DMV License Suspension Classification

## 1. Executive Summary
Built an NLP-powered binary classification system to predict DMV license suspension from court violation and driving record text, deployed on Databricks with a full CI/CD pipeline (Docker, GitHub Actions, JFrog). The project systematically compared multiple NLP approaches — SparkNLP lemmatization, TF-IDF, spaCy embeddings, pretrained Transformer models (USE, sBERT, BERT), and XGBoost — combined with Information Value feature selection and L1-regularized logistic regression, producing decile-based gains tables and standardized coefficient analysis for model interpretability.

## 2. Business / Product Background
DMV suspension status is a critical risk indicator for auto insurance underwriting:
- Predicts whether a driver has a current or historical DMV license suspension
- Uses court violation descriptions and disposition records as primary text inputs
- Supports LexisNexis Risk Solutions (RELX) insurance analytics products
- Combines text features with categorical violation attributes for comprehensive risk scoring
- Production deployment via Docker + KEL (Knowledge Engineering Language) on JFrog/AKS infrastructure

## 3. Data Background
- **Input**: `input_file.csv` / `input_file_new.csv` (tilde-delimited) from HPCC analytics mount (`/mnt/analytics/auto/auto_mvr/suspension_svcs/`)
- **Target variable**: `is_dmv_suspended` / `is_suspended` (binary — combines `is_DMV_current_suspended` and `is_dmv_suspended`)
- **Text columns**: `af_violdesc` (violation description), `af_dispositiondesc` (disposition), `af_casedesc` (case description)
- **Categorical features**: 11 variables including `dmv_state_postal_code`, `af_violtype`, `af_violstrength`, `mbsi_svc_desc`, `mbsi_svc_category`, `mbsi_svc_major_minor`, `af_dispcode`
- **States analyzed**: FL (304K suspended / 378K not), VA (82K/281K)
- **Granularity**: Per-driver (`idl`), with violation lists aggregated across records

## 4. Technical Approach
### NLP Feature Engineering (Multi-Approach Comparison)
- **SparkNLP Pipeline**: DocumentAssembler → Tokenizer → Normalizer → LemmatizerModel.pretrained() → StopWordsCleaner → NGram(n=2)
- **spaCy Lemmatization**: `en_core_web_sm` with pandas_udf for lemma extraction
- **spaCy Embeddings**: `en_core_web_md` — averaged 300-dim word vectors as document embeddings
- **TF-IDF + Chi-Square Selection**: CountVectorizer → IDF pipeline with ChiSqSelector (top-20 features)
- **HashingTF**: Alternative featurization with numFeatures=10,000

### Pretrained Transformer Embeddings (4 models)
- Universal Sentence Encoder (`tfhub_use`)
- sBERT (`sent_small_bert_L2_128`)
- sBERT Legal domain (`sent_bert_base_uncased_legal`)
- BERT base uncased (`bert_base_uncased`)
- Models loaded from `/mnt/analytics/auto/LLM/models/`

### Statistical Feature Selection
- **Information Value (IV)**: Computed WOE and IV for all 11 categorical variables
- **Top IV variable**: `mbsi_svc_desc` at IV=1.26 (very strong predictive power)
- **Top discriminating token**: "DRIV WHILE LIC SUSP/REV" with WOE=2.58, contributing IV=0.437

### Classification Models
- **Logistic Regression**: L1 regularization (`elasticNetParam=1.0`), 60/40 train/validation split
- **XGBoost**: SparkXGBClassifier with maxDepth=5, n_estimators=100, binary:logistic
- **Bigram + LR**: NGram(n=2) → CountVectorizer → L1 Logistic Regression with coefficient analysis

### Named Entity Recognition
- GloVe-based NER (`ner_dl`) on disposition descriptions for entity extraction

### Evaluation
- AUC-ROC for model comparison
- Decile-based gains tables partitioned by state
- KS statistic, cumulative lift
- Standardized coefficient analysis (feature importance via std deviation mapping)

## 5. My Role and Contribution
- **Designed and implemented the complete NLP classification pipeline** from data ingestion through model evaluation
- **Systematically compared 8+ NLP approaches** (lemmatization, TF-IDF, spaCy embeddings, 4 pretrained Transformers, n-grams)
- **Developed Information Value analysis** identifying the strongest categorical predictors (mbsi_svc_desc, IV=1.26)
- **Built production-ready infrastructure**: Dockerfile, Maven/KEL build, GitHub Actions CI/CD, JFrog deployment
- **Created interpretable model outputs**: Standardized coefficients, decile gains tables, per-state KS analysis

## 6. Key Results and Impact
- **IV Analysis**: `mbsi_svc_desc` variable alone achieves IV=1.26 — extremely strong predictor; single token "DRIV WHILE LIC SUSP/REV" contributes IV=0.437
- **Multi-approach comparison**: Evaluated text embedding, lemmatization, n-gram, and Transformer approaches for optimal text representation
- **State-level patterns**: FL and VA show distinct suspension rate distributions, informing state-specific modeling
- **Production deployment path**: Complete Docker + JFrog + GitHub Actions + AKS pipeline for KEL-based runtime serving
- **Interpretable features**: L1 regularization + standardized coefficients provide transparent, auditable model for compliance

## 7. Challenges and Solutions
- **Unstructured text variability**: Court violation descriptions vary wildly → Multiple NLP approaches compared (lemmatization, embeddings, n-grams) to find optimal representation
- **High-cardinality categoricals**: 11 categorical variables with many levels → Information Value analysis to rank and filter
- **State heterogeneity**: Suspension patterns differ by state → State-partitioned gains tables and per-state KS statistics
- **Model interpretability**: Black-box NLP models lack transparency → L1 regularization with standardized coefficient mapping back to vocabulary terms
- **Production serving**: Python NLP in production → KEL/Java-based runtime with Docker containerization on AKS

## 8. Job Application Story
- **Situation**: LexisNexis's insurance underwriting products needed to determine DMV license suspension risk from unstructured court violation records — a text classification problem that hundreds of thousands of records flowed through annually across states like FL (680K+ records) and VA (360K+ records). The existing rule-based approach lacked scalability and couldn’t capture the nuances in violation description text.
- **Task**: As technical lead, I designed an end-to-end NLP classification system, defining the evaluation strategy across multiple text representation approaches and owning the decision on which approach to deploy to production.
- **Action**: I systematically evaluated 8+ NLP approaches (SparkNLP lemmatization, TF-IDF with Chi-Square top-20 selection, spaCy 300-dim embeddings, 4 pretrained Transformer models including domain-specific sBERT-Legal, bigram models, and XGBoost). I computed Information Value for 11 categorical features, discovering that `mbsi_svc_desc` alone achieved IV=1.26 — and a single token "DRIV WHILE LIC SUSP/REV" contributed IV=0.437. I built L1-regularized logistic regression models with standardized coefficient analysis, providing the interpretability required for insurance regulatory compliance. I evaluated all approaches via decile gains tables with state-partitioned KS statistics, then designed the production deployment pipeline — Docker containerization, GitHub Actions CI/CD with 4 workflow stages, JFrog Artifactory for artifact hosting, and KEL runtime serving on AKS. I collaborated with engineering to align the deployment with existing infrastructure and presented the comparative NLP evaluation results to product stakeholders.
- **Result**: Delivered a validated suspension classification model processing hundreds of thousands of violation records across multiple states, with transparent feature importance meeting regulatory audit requirements. The complete production pipeline (Docker/CI-CD/AKS) reduced the deployment cycle from manual handoffs to automated continuous delivery, and the Information Value framework I developed became a reusable feature selection methodology adopted by the team for subsequent projects.

## 9. Relevant Skills Demonstrated
- **NLP**: SparkNLP, spaCy, TF-IDF, CountVectorizer, n-grams, lemmatization, NER, pretrained Transformers (USE, sBERT, BERT)
- **ML**: Logistic Regression (L1/Lasso), XGBoost, feature selection (Chi-Square, Information Value/WOE)
- **Big Data**: PySpark, Databricks, Parquet, Azure Blob mounts
- **MLOps/DevOps**: Docker, GitHub Actions CI/CD, JFrog Artifactory, Maven, KEL (Knowledge Engineering Language)
- **Evaluation**: AUC-ROC, KS statistic, gains tables, standardized coefficients, lift analysis
- **Domain**: Insurance underwriting, DMV/MVR data, court violation records

## 10. Best-Fit Job Types
- **NLP Data Scientist** — Text classification with multiple NLP approaches
- **ML Engineer** — End-to-end pipeline from NLP to production deployment
- **Applied Scientist** — Systematic model comparison with production constraints
- **Insurance Data Scientist** — Domain-specific risk classification
- **MLOps Engineer** — Docker, CI/CD, model serving infrastructure

## 11. Resume Bullet Suggestions
- Led the design and evaluation of an NLP-based DMV suspension classifier, systematically comparing 8+ text representation approaches (SparkNLP, spaCy, TF-IDF, 4 pretrained Transformers) on 680K+ court violation records across multiple states
- Developed Information Value analysis framework identifying key categorical predictors (top variable IV=1.26) and individual tokens contributing IV=0.437, establishing a reusable feature selection methodology adopted team-wide
- Built L1-regularized logistic regression with standardized coefficient analysis, providing transparent and auditable predictions that meet insurance regulatory compliance requirements
- Designed production deployment pipeline with Docker, GitHub Actions CI/CD (4 workflow stages), JFrog Artifactory, and KEL runtime serving on AKS, reducing deployment from manual handoffs to automated continuous delivery
- Evaluated 4 pretrained Transformer models (USE, sBERT, sBERT-Legal, BERT) for insurance text embeddings on Databricks/PySpark, benchmarking domain-specific vs. general-purpose models
- Created state-partitioned decile gains table analysis with KS statistics for multi-state model validation, demonstrating distinct suspension patterns across FL (304K/378K) and VA (82K/281K)

## 12. Interview Talking Points
- **NLP strategy**: "I compared 8+ NLP approaches for court violation text classification — from basic TF-IDF to pretrained Transformers including a legal-domain sBERT model. The key insight was that Information Value analysis on categorical features (IV=1.26 for the service description variable) provided strong signal even before NLP text processing — which informed our decision to combine structured categorical features with text-derived features rather than relying on text alone."
- **Feature discovery**: "A single token — 'DRIV WHILE LIC SUSP/REV' — contributed IV=0.437 by itself, showing that domain-specific vocabulary in violation records carries enormous predictive power. This discovery shaped our feature engineering strategy across the team's other NLP projects."
- **Interpretability for compliance**: "In insurance, model transparency isn't optional. I used L1 regularization with standardized coefficient analysis to map model weights back to human-readable text features, making every prediction auditable — critical for regulatory filings and carrier trust."
- **Production deployment**: "I designed a complete CI/CD pipeline: GitHub Actions triggers Docker builds across 4 workflow stages, JFrog Artifactory hosts versioned artifacts, and the KEL runtime serves predictions on AKS. This reduced our deployment cycle from days of manual handoffs to automated continuous delivery."
- **Scale and impact**: "The model processes hundreds of thousands of violation records across FL, VA, and other states. I presented the comparative evaluation results to product stakeholders, demonstrating clear lift over the previous rule-based approach and securing production deployment approval."

## 13. Evidence Found
- **4 Databricks notebooks**: `step1_input_data.py` (exploration), `step1_newdata.py` (comprehensive with IV + embeddings + LR), `step1_newdata_simpleapproach.py` (simplified pipeline), `step2_lemmas_model.py` (alternative NLP approaches)
- **`cate_iv.csv`**: Complete Information Value analysis with WOE for 11 categorical variables
- **Production infrastructure**: Dockerfile (Corretto JDK 17), pom.xml (Maven/KEL/Tardis), 4 GitHub Actions workflows (build, deploy, JUnit, PUML), JFrog settings
- **Pretrained models**: 4 Transformer models loaded from `/mnt/analytics/auto/LLM/models/`
- **NER pipeline**: GloVe-based named entity recognition on disposition text
