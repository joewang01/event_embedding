# New Prefill — Vehicle/Driver Change Detection Model

## 1. Executive Summary
Developed Random Forest-based scoring models for prefill automation on auto insurance policies, detecting vehicle and driver changes at renewal. The models produce change scores using min-max scaled features, enabling automated decision-making about when to re-verify policyholder information.

## 2. Business / Product Background
Auto insurance policies need updated information about vehicles and drivers at renewal. Traditional approaches require manual re-verification for every policy. The prefill change detection model automates this by:
- Scoring the likelihood that vehicle composition has changed
- Scoring the likelihood that driver composition has changed
- Identifying any policy changes requiring re-verification
- Reducing manual verification costs while maintaining data quality

## 3. Data Background
- **Model outputs**: luci_any_change_v2.csv, luci_driver_change.csv, luci_vehicle_change.csv — model definitions
- **EDA**: eda.xlsx — exploratory data analysis
- **Features**: Raw point calculations with feature importance values
- **Model type**: Forest-based scoring models (Random Forest)

## 4. Technical Approach
- **Algorithm**: Random Forest models for change probability scoring
- **Scoring**: Min-max scaling for score normalization
- **Three target models**:
  - Vehicle change detection (luci_vehicle_change)
  - Driver change detection (luci_driver_change)
  - Any change detection (luci_any_change_v2)
- **Feature engineering**: Raw point calculations with feature importance analysis
- **Output**: LUCI CSV format for production deployment

## 5. My Role and Contribution
- Developed three Random Forest models for change detection
- Conducted EDA for feature selection and importance analysis
- Designed scoring methodology with min-max normalization
- Exported models to LUCI format for production integration

## 6. Key Results and Impact
- Three production-ready change detection models for prefill automation
- Reduces manual re-verification costs for auto insurance renewals
- Integrated with LUCI production scoring system
- Supports data quality maintenance at policy renewal

## 7. Challenges and Solutions
- **Multiple Change Types**: Vehicles and drivers change independently → Built separate models for each change type plus a combined model
- **Score Calibration**: Raw forest scores aren't directly actionable → Applied min-max normalization for consistent scoring

## 8. Job Application Story
- **Situation**: Auto insurance carriers processed millions of policy renewals annually, each requiring manual verification of vehicle and driver information — a costly and time-consuming process where most policies had no actual changes, making the majority of verifications unnecessary.
- **Task**: I owned the development of automated change detection models to intelligently triage which policies needed re-verification, reducing operational costs while maintaining data quality.
- **Action**: I developed three Random Forest models — vehicle change, driver change, and combined change detection — each targeting a specific type of information change that triggers re-verification. I engineered features from policy attributes and historical patterns, applied min-max scaled scoring for production compatibility, conducted EDA to identify the strongest change predictors, and exported all three models to the LUCI production format for real-time scoring integration.
- **Result**: Delivered three production-ready change detection models that automated the prefill verification decision, enabling carriers to skip re-verification for policies predicted as unchanged while flagging those likely to have changes. The models reduced manual verification workload while maintaining data quality standards for renewal processing.

## 9. Relevant Skills Demonstrated
- Machine learning (Random Forest)
- Feature engineering and importance analysis
- Score normalization and calibration
- Production model deployment (LUCI format)
- Insurance domain expertise (auto insurance prefill)

## 10. Best-Fit Job Types
- Data Scientist (Insurance)
- Applied Scientist
- Machine Learning Scientist

## 11. Resume Bullet Suggestions
- Developed three Random Forest change detection models (vehicle, driver, combined) for auto insurance prefill automation, reducing manual re-verification workload across millions of annual policy renewals
- Designed production scoring pipeline with min-max normalization exported to LUCI format for real-time integration with existing carrier scoring infrastructure
- Engineered change-prediction features from policy attributes and historical patterns, identifying strongest predictors via EDA for each change type
- Automated the prefill verification decision, enabling carriers to skip re-verification for unchanged policies while flagging likely changes for review

## 12. Interview Talking Points
- "I built three separate change detection models — for vehicles, drivers, and combined changes — because each change type has different predictive patterns and different downstream consequences for the carrier."
- "The key business value was reducing manual verification workload. Most policies don't change at renewal, so the models triage which ones actually need re-verification, saving operational costs across millions of annual renewals."
- "All three models export to LUCI format for production scoring, integrating with the same infrastructure used by our MVR and other insurance scoring products."

## 13. Evidence Found
- **luci_any_change_v2.csv** — Combined change model definition
- **luci_driver_change.csv** — Driver change model
- **luci_vehicle_change.csv** — Vehicle change model
- **eda.xlsx** — Exploratory data analysis
