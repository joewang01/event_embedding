# MV Lien — Motor Vehicle Lien Attribute Analysis

## 1. Executive Summary
Developed motor vehicle lien analysis and attribute engineering through 3 model versions (v1–v3). The project models the relationship between vehicle ownership/lien status and insurance risk, creating new predictive features from lien data for scoring products.

## 2. Business / Product Background
Vehicle liens (outstanding loans on vehicles) are indicators of financial behavior:
- Lien status correlates with insurance risk and payment behavior
- Lien attributes enrich existing scoring models
- 3 versions demonstrate iterative attribute refinement

## 3. Data Background
- **Attribute documentation**: MV_attribute_liens.xlsx, MV_attribute_liens_v2.xlsx, MV_attribute_liens_v3.xlsx

## 4. Technical Approach
- Attribute engineering from motor vehicle lien data
- Risk segmentation by lien status
- 3 iterative versions with progressive refinement

## 5. My Role and Contribution
- Developed MV lien attributes through 3 versions
- Analyzed vehicle ownership/lien patterns for risk segmentation

## 6. Key Results and Impact
- 3 versions of lien attributes for scoring model enrichment
- New predictive features from vehicle lien data

## 7. Challenges and Solutions
- **Feature Design**: Extracting meaningful risk signals from lien data → 3 iterations of attribute refinement

## 8. Job Application Story
- **Situation**: Insurance scoring models needed enrichment with vehicle lien data — lien status and ownership patterns provide financial behavior signals that improve risk prediction beyond traditional driving history.
- **Task**: I developed lien-based attributes through 3 iterative versions, refining feature engineering based on model performance feedback.
- **Action**: I analyzed motor vehicle lien patterns, engineered predictive attributes capturing lien status, ownership transitions, and financial behavior signals, and refined through v1 to v3 based on downstream model lift analysis.
- **Result**: Delivered v3 lien attributes enriching scoring models with vehicle ownership and financial behavior signals, demonstrating iterative feature engineering driven by model performance feedback.

## 9. Relevant Skills Demonstrated
- Feature engineering, risk segmentation, attribute development, insurance domain

## 10. Best-Fit Job Types
- Data Scientist, Feature Engineer, Applied Scientist

## 11. Resume Bullet Suggestions
- Engineered motor vehicle lien attributes through 3 iterative versions, enriching insurance scoring models with financial behavior signals
- Refined feature engineering through v1–v3 based on downstream model lift analysis, demonstrating iterative improvement methodology
- Captured lien status, ownership transitions, and financial behavior patterns that improved risk prediction beyond traditional driving history

## 12. Interview Talking Points
- "I engineered attributes from motor vehicle lien data — lien status and ownership patterns provide strong signals for insurance risk prediction that traditional driving history misses."
- "The 3-version iteration was driven by model performance feedback — each version refined features based on downstream lift analysis rather than intuition."

## 13. Evidence Found
- **MV_attribute_liens.xlsx** (v1–v3) — 3 versions of lien attribute documentation
