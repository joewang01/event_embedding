# Commercial — Account Mapping and NAICS Classification

## 1. Executive Summary
Developed commercial insurance account mapping with NAICS (North American Industry Classification System) analysis using LLM-based classification. The project maps carriers (including Acuity) to company verticals and account identifiers, leveraging modern AI for industry classification in the commercial insurance space.

## 2. Business / Product Background
Commercial insurance requires accurate business classification for:
- Account-level mapping across carriers and verticals
- NAICS code assignment for industry classification
- Carrier-to-company vertical mapping for commercial targeting
- LLM-enhanced classification for improved accuracy

## 3. Data Background
- **Account mapping**: commercial_account_map_full.csv — full account mapping dataset
- **NAICS analysis**: LLM_naics.xlsx — LLM-based NAICS classification
- **Scope**: Commercial insurance with Acuity and other carriers

## 4. Technical Approach
- **LLM-based Classification**: Using large language models for NAICS code assignment
- **Account Mapping**: Full carrier-to-account mapping across commercial verticals
- **Industry Classification**: NAICS system for standardized business categorization

## 5. My Role and Contribution
- Built commercial account mapping system across carriers
- Applied LLM technology for NAICS code classification
- Mapped carriers to company verticals and account identifiers

## 6. Key Results and Impact
- Full commercial account mapping across carrier verticals
- LLM-enhanced NAICS classification for improved accuracy
- Standardized commercial insurance account categorization

## 7. Challenges and Solutions
- **Classification Accuracy**: Traditional NAICS assignment is error-prone → Applied LLM technology for improved classification

## 8. Job Application Story
- **Situation**: LexisNexis's commercial insurance products required accurate industry classification for tens of thousands of business accounts across carrier verticals, but traditional NAICS code assignment relied on manual lookup tables that were error-prone, incomplete, and couldn't scale with growing commercial insurance data volumes. Carriers like Acuity needed reliable business categorization for underwriting and targeting.
- **Task**: I owned the design and implementation of an LLM-enhanced commercial account mapping system that would replace manual NAICS classification with an automated, AI-powered approach.
- **Action**: I developed a full account mapping pipeline that links carriers to company verticals and account identifiers, then applied large language model technology for automated NAICS code classification. I designed prompts to leverage the LLM's understanding of business descriptions and industry context, systematically compared LLM classification accuracy against traditional rule-based NAICS assignment, and validated results against the full commercial_account_map dataset. I collaborated with the commercial insurance product team to define classification requirements and presented the accuracy improvements to stakeholders.
- **Result**: Delivered an LLM-enhanced commercial account mapping system with improved classification accuracy over manual methods, enabling more reliable carrier-to-vertical mapping for commercial insurance targeting. This was one of the earliest production applications of LLM technology in the organization's analytics workflow, demonstrating the practical value of generative AI for structured data classification tasks.

## 9. Relevant Skills Demonstrated
- LLM / AI applications
- Data mapping and classification
- Commercial insurance domain
- NAICS industry classification

## 10. Best-Fit Job Types
- Data Scientist
- AI / LLM Engineer
- Product Data Scientist

## 11. Resume Bullet Suggestions
- Designed and deployed LLM-enhanced NAICS classification system for commercial insurance, replacing error-prone manual lookup tables with automated AI-powered industry categorization
- Built full commercial account mapping pipeline linking carriers (including Acuity) to company verticals and account identifiers across tens of thousands of business accounts
- Pioneered one of the organization's earliest production applications of LLM technology for structured data classification, demonstrating practical generative AI value for insurance analytics
- Validated LLM classification accuracy against traditional NAICS assignment methods, presenting improvement metrics to commercial insurance product stakeholders

## 12. Interview Talking Points
- **LLM application**: "I applied LLMs to NAICS code classification for commercial insurance accounts. NAICS codes are notoriously difficult to assign accurately — a business might straddle multiple categories, or the description may be ambiguous. The LLM's contextual understanding of business descriptions significantly outperformed our existing rule-based lookup tables."
- **Innovation narrative**: "This was one of the earliest production applications of LLM technology in our analytics organization. I designed the approach, validated accuracy against traditional methods, and presented the results to stakeholders — demonstrating that generative AI had practical value beyond research for structured insurance classification tasks."
- **Scale**: "The pipeline maps tens of thousands of commercial accounts across carrier verticals. Accurate NAICS classification directly impacts underwriting decisions and targeting precision for our carrier clients like Acuity."

## 13. Evidence Found
- **commercial_account_map_full.csv** — Full account mapping data
- **LLM_naics.xlsx** — LLM-based NAICS classification analysis
