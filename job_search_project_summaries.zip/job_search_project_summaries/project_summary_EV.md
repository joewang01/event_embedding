# EV — Electric Vehicle Insurance Loss Cost Modeling

## 1. Executive Summary
Designed and built a multi-stage XGBoost Tweedie residual modeling system for Electric Vehicle (EV) insurance pricing on Databricks/PySpark. The models predict loss cost across coverage types using a novel 3-stage offset approach: (1) baseline underwriting variables, (2) EV-specific technical attributes (battery, powertrain, range), and (3) vehicle transition attributes measuring how an EV differs from other vehicles in the owner's garage. Includes credit score adjustment logic for regulatory compliance (CA, MA, HI, MI), a reusable gains chart utility library (V1 and V2.1), and a full Databricks Asset Bundle deployment with Delta Live Tables. Supported by 9 Excel workbooks for GLM additive/ratio/residual modeling and exploratory analysis.

## 2. Business / Product Background
Electric vehicles present unique insurance pricing challenges:
- EV-specific risk factors (battery type, voltage, powertrain configuration, charging times) have no historical baseline
- Owners transitioning to EVs may drive differently depending on their previous vehicle portfolio
- Standard underwriting variables alone are insufficient — EV attributes provide incremental predictive lift
- Regulatory compliance: credit score usage restricted in CA, MA, HI, MI (forced to zero)
- Supports collision coverage pricing with extension to other coverage types
- Analyzed 25+ car brands (Tesla, Chevrolet, Ford, Toyota, BMW, etc.) and policy segments (Endorsement, Renewal, New Business)

## 3. Data Background
- **Primary datasets**: `ev_control_md2.csv` / `ev_control_md_2023.csv` — policy/vehicle level with claims, exposure, EV attributes
- **Transition attributes**: `transi_attr_ev_2023.csv` — 200+ features measuring vehicle differences within household garage (weight, HP, torque, MSRP, dimensions)
- **Target variable**: `loss_cost` = `claim_amount / exposure`
- **Coverage filter**: Collision (`coverage_type == 'CO'`) with `coll != 0`
- **Storage**: DBFS mounts (`/mnt/analytics/sharedresources/`) → Parquet
- **Output artifacts**: `prediction_flags.csv` (VINs flagged as top/bottom/middle 10%), 9 Excel workbooks, PNG gain charts

### Feature Groups
- **Control attributes** (22): vehiclecnt, drivercnt, attract_auto_v3, male, age, population_density, pre_claim_cnt, coll, chargeable violations (DUI/major/minor), Prior_BI categories
- **EV-specific attributes** (15+): battery_voltage, battery_capacity_kwh, powertrain_motorcount, total_motor_power, total_motor_torque, motor1/2/3 power and torque, electric_range_miles, onboard_charger_power, DC_fast_charging_time, regular_charging_time, battery_type, electrification_type
- **Ownership attributes** (12+): count of active vehicles (ICE/EV/PHEV/HEV), years_since_earliest_ev, prior_ev_ownership, years_owning_latest_ev, brand_latest_ev, prior_ev_brand
- **Transition attributes** (200+): diff/pct_diff vs min/max/avg/weighted of all-garage and active-garage for weight, hp, torque, length, width, height, power-to-weight, MSRP, model year, hip/leg/headroom

## 4. Technical Approach
### 3-Stage Offset/Residual Modeling
1. **Stage 1 — Baseline**: XGBoost Tweedie regression on `loss_cost` using control attributes only. Grid search over tweedie_variance_power [1.3, 1.5, 1.7, 1.9], learning_rate [0.01, 0.05, 0.1], max_depth [4, 6, 8]. 3-fold CV with early stopping. Predictions adjusted by symbolling factor (coll), normalized to align training means. Residuals = `loss_cost - normalized_prediction`.
2. **Stage 2 — EV Attributes**: XGBoost Tweedie on residuals from Stage 1 using EV-specific technical attributes. Residual floor = 125 (below → 0). Params: tweedie 1.5, max_depth 5, eta 0.05, 200 rounds, early_stopping 10.
3. **Stage 3 — Ownership/Transition**: XGBoost Tweedie on residuals from Stage 2 using ownership attributes or 10 selected transition features. Residual floor = 234. max_depth 6. Final prediction = sum of all three stages.

### Transition Modeling (Standalone)
- Separate 2-stage model: baseline XGBoost → transition residual XGBoost (multiplicative: `loss_cost / normalized_prediction`)
- 10 selected transition features: diff_vs_min_all_garage_vehheight, pct_diff_weighted_all_weight, diff_vs_min_active_garage_width, pct_diff_avg_active_headroom, diff_vs_min_active_garage_pwrwgt, diff_vs_avg_active_garage_torque, pct_diff_avg_all_legroom, diff_vs_max_all_garage_length, pct_diff_min_active_hp, pct_diff_avg_active_hiproom
- Output: `prediction_flags.csv` — VINs flagged as top 10%, bottom 10%, or middle 10% by prediction delta

### Credit Score Adjustment (Regulatory Compliance)
- CA, MA, HI, MI: `attract_auto_v3` forced to 0 (credit score prohibited)
- Other states: zero-rate credit scores downsampled to ~8% per state using stratified random sampling

### Reusable Utility Library (V1 + V2.1)
- `Metrics()`: Computes Gini, KS, Information Value, TBR (Top-to-Bottom Ratio)
- `gains_chart()`: Full gains chart — claim frequency, uncapped/capped severity, loss cost, exposure, earned premium
- `gains_chart_to_excel()`: Formatted Excel export with embedded charts
- `weighted_quantile()`: NumPy-based weighted percentile calculation
- `decile_profile_by_coverage()`: Per-coverage-type profiling with equal-frequency bucketing

### Databricks Asset Bundle
- Workspace: `adb-18379745488365.5.azuredatabricks.net`
- Catalog: `insanalytics_prod`, schema `ev_${target}`
- DLT pipeline (`ev_pipeline`) + scheduled job (`ev_job`, daily trigger)
- `EV_modeling_2023.ipynb`: Massive 290-cell, ~14K-line notebook — full 2023 modeling workflow

### GLM Workbooks (9 Excel files)
- GLM additive modeling, ratio modeling, residual modeling (2022 + 2023)
- Control model review, frequency EDA, modeling iteration logs

## 5. My Role and Contribution
- **Designed the complete 3-stage residual modeling architecture**, isolating incremental contributions of baseline, EV-specific, and ownership/transition attributes
- **Engineered 200+ transition features** measuring how each EV compares to other vehicles in the owner's garage across physical dimensions, performance, and price
- **Implemented credit score regulatory compliance** with state-specific zero-out and downsampling for CA/MA/HI/MI
- **Built reusable Metrics + Gains Chart utility library** (V1 and V2.1) used across multiple projects
- **Deployed on Databricks** with asset bundles, DLT pipeline, and scheduled jobs
- **Conducted extensive validation** across 25+ car brands, 3 policy segments, CA vs. non-CA, with Gini/KS/TBR metrics and decile gains charts
- **Created VIN flagging system** identifying top/bottom risk vehicles for underwriting review
- **Developed GLM-based models** (additive, ratio, residual) as complementary approaches in Excel workbooks

## 6. Key Results and Impact
- **Novel EV pricing capability**: First multi-stage model separating EV-specific technical attributes (battery, powertrain, range) from standard underwriting variables
- **Transition attributes lift**: 10 selected garage-comparison features provide measurable incremental lift over baseline + EV attributes alone
- **25+ brand coverage**: Model validated across Tesla, Chevrolet, Ford, Toyota, BMW, and 20+ additional EV brands
- **Regulatory compliance**: Credit-adjusted models for CA, MA, HI, MI — ready for deployment in restricted-credit states
- **Production-ready**: Databricks Asset Bundle with DLT pipeline and daily job scheduling
- **Reusable tooling**: Gains chart library (V2.1) reused across multiple insurance modeling projects

## 7. Challenges and Solutions
- **No EV pricing history**: First-generation EV loss cost models → Designed 3-stage residual approach to isolate incremental EV attribute contributions
- **200+ transition features**: High dimensionality → Selected top 10 features based on individual variable analysis and profiling
- **Credit score regulations**: State-level restrictions on credit usage → Implemented state-specific zero-out + 8% downsampling for regulatory compliance
- **Residual floor selection**: Negative residuals distort Stage 2/3 training → Applied empirical floors (125, 234) to prevent noise fitting
- **Symbolling factor adjustment**: Raw predictions need collision symbol alignment → Normalized by multiplying by coll factor and rescaling to match training means
- **Cross-segment validation**: Model performance varies by policy segment → Validated separately for Endorsement/Renewal/New Business and CA vs. non-CA

## 8. Job Application Story
- **Situation**: Electric vehicles represent the fastest-growing segment of the US auto insurance market, yet traditional pricing models had no mechanism to account for EV-specific risk factors — battery configuration, powertrain specifications, charging behavior — or the behavioral shifts that occur when drivers transition from ICE to EV vehicles. LexisNexis needed a pricing model before competitors filled the gap, and it needed to comply with credit score regulations in 4 states.
- **Task**: As technical lead, I designed and built a comprehensive EV loss cost modeling system that isolates the incremental predictive contribution of EV-specific attributes and vehicle transition features — the first such model in the organization's product portfolio.
- **Action**: I developed a novel 3-stage XGBoost Tweedie residual architecture: Stage 1 captures baseline underwriting risk from 22 control variables, Stage 2 adds 15+ EV-specific technical attributes (battery voltage, powertrain motor count, electric range, charging times), and Stage 3 incorporates the top 10 selected from 200+ vehicle transition features I engineered — measuring how each EV differs from other vehicles in the owner’s garage across weight, horsepower, torque, dimensions, and MSRP. I implemented credit score regulatory compliance for CA, MA, HI, MI (zero-out with stratified downsampling to 8%), built a reusable Metrics/Gains Chart utility library (V2.1) that the team adopted for other projects, validated across 25+ car brands and 3 policy segments (Endorsement/Renewal/New Business), and deployed the full pipeline via Databricks Asset Bundles with Delta Live Tables and daily automated scheduling. I presented the 3-stage architecture and validation results to actuarial stakeholders and product leadership to secure production approval.
- **Result**: Delivered the organization's first production-ready EV pricing model with measurable lift from EV-specific and transition attributes at each stage — the 3-stage approach demonstrating that vehicle transition features provide incremental value even after accounting for EV attributes alone. The model includes regulatory-compliant credit adjustment for 4 restricted states, a VIN flagging system identifying highest/lowest risk vehicles for underwriting review, and a fully automated Databricks pipeline processing new data daily.

## 9. Relevant Skills Demonstrated
- **ML**: XGBoost (Tweedie regression), residual/offset modeling, grid search with 3-fold CV, early stopping
- **Feature engineering**: 200+ vehicle transition features, EV technical attributes, categorical handling, symbolling factor adjustment
- **Big Data**: PySpark, Databricks (Delta Live Tables, Asset Bundles, Unity Catalog), Parquet
- **Actuarial/GLM**: GLM additive and ratio modeling, residual analysis, Gini/KS/TBR metrics
- **Regulatory**: Credit score compliance (state-level restrictions, stratified downsampling)
- **Tooling**: Reusable gains chart library (V2.1), weighted quantile computation, Excel export with charts
- **Domain**: EV insurance pricing, collision coverage, multi-brand validation

## 10. Best-Fit Job Types
- **Insurance Data Scientist** — EV pricing, loss cost modeling, regulatory compliance
- **Actuarial Data Scientist** — GLM + ML hybrid modeling, Tweedie regression
- **Staff Data Scientist** — Multi-stage model architecture design, reusable tooling
- **ML Engineer** — Databricks deployment, DLT pipelines, asset bundles
- **Pricing Scientist** — Vehicle risk segmentation, coverage-level modeling

## 11. Resume Bullet Suggestions
- Designed and built the organization's first EV insurance pricing model using a novel 3-stage XGBoost Tweedie residual architecture, isolating incremental contributions of baseline underwriting, EV technical attributes, and vehicle transition features
- Engineered 200+ vehicle transition features comparing EV characteristics to household garage portfolio (weight, HP, torque, MSRP, dimensions), selecting the top 10 via individual variable profiling that provided measurable incremental lift over baseline+EV models
- Implemented credit score regulatory compliance for CA, MA, HI, MI with state-specific zero-out and stratified downsampling to 8% zero-rate target, ensuring model deployability across all US states
- Built reusable Metrics/Gains Chart utility library V2.1 (Gini, KS, TBR, decile gains, Excel export) adopted across multiple insurance modeling projects team-wide
- Deployed full EV pricing pipeline on Databricks with Delta Live Tables, Asset Bundles, and daily automated job scheduling, processing new policy data continuously
- Validated model across 25+ car brands (Tesla, Chevrolet, Ford, BMW, Toyota) and 3 policy segments with state-level performance analysis and VIN-level risk flagging for underwriting review
- Presented 3-stage architecture design and validation results to actuarial stakeholders and product leadership, securing production deployment approval

## 12. Interview Talking Points
- **Architecture innovation**: "I designed a 3-stage residual approach because EV pricing has no historical baseline. Stage 1 captures standard underwriting risk, Stage 2 isolates the incremental effect of EV-specific attributes like battery capacity and powertrain configuration, and Stage 3 measures how the EV differs from other vehicles in the owner's garage. Each stage targets the residual from the previous one, so I can quantify exactly how much lift each attribute group adds."
- **Feature engineering depth**: "I engineered 200+ transition features measuring differences between each EV and the owner's garage portfolio — for example, the percentage power-to-weight ratio difference versus their most powerful active vehicle. From those 200+, I selected the top 10 through individual variable profiling, and those 10 provided measurable incremental lift even after the EV attributes were already in the model."
- **Regulatory compliance**: "Credit scores are prohibited in 4 states for auto insurance pricing. I implemented a compliant approach: zero-out credit in restricted states and downsample zero-rate records to 8% in other states using stratified sampling — this prevents the model from treating zero-credit as informative while maintaining regulatory compliance."
- **Stakeholder leadership**: "I presented the 3-stage architecture to actuarial and product leadership, demonstrating that the residual approach provides interpretable, stage-by-stage lift — which was critical for actuarial filing justification. This was the organization's first EV-specific pricing model."
- **Production deployment**: "The entire pipeline runs on Databricks with Delta Live Tables and Asset Bundles — data ingestion, model training, gains chart generation, and VIN flagging — all scheduled as a daily automated job, making it the first fully automated ML pipeline in our team's portfolio."

## 13. Evidence Found
- **Python code (EV/EV/)**: `EV_modeling.py` (original 3-stage model), `EV_modeling_2023.py` (2023 refresh with transition attributes), `EV_modeling_2023_creditsampletest.py` (credit test variant), `Transition_modeling_2023.py` (standalone transition model), `Gains_chart_template.py`, `Utility_Functions_Metrics_Gain_Chart.py` (V1), `Utility_Functions_Metrics_Gains_Chart_V2_1.py` (V2.1)
- **Databricks (EV/databricks/ev/)**: Asset bundle (databricks.yml), DLT pipeline, `EV_modeling_2023.ipynb` (290-cell, ~14K-line master notebook), job configs, tests
- **Output**: `prediction_flags.csv` (VIN flagging), 3 PNG charts (claim frequency, severity, loss cost)
- **Excel workbooks (9)**: GLM additive/ratio/residual modeling (2022 + 2023), control model, frequency EDA, iteration logs
