# Renew Retention — Attrition Model Scorecard (2012)

## 1. Executive Summary
Developed a renewal retention (attrition) model scorecard for predicting insurance policy non-renewal (2012). The model scored policyholders' likelihood of lapsing at renewal, enabling targeted retention campaigns.

## 2. Business / Product Background
Policy retention is a key profitability driver:
- Predict which policyholders are at risk of non-renewal
- Enable targeted retention interventions (discounts, outreach)
- Reduce churn and maintain portfolio size
- Scorecard format for business user interpretability

## 3. Data Background
- **Period**: 2012 model development
- **Target**: Policy non-renewal (attrition)
- **Format**: Scorecard model

## 4. Technical Approach
- Attrition prediction model development
- Scorecard methodology for transparent risk scoring
- Feature engineering from policy and customer attributes
- Validation and lift analysis for retention targeting

## 5. My Role and Contribution
- Developed attrition prediction scorecard
- Selected and engineered features for retention modeling
- Validated model performance and lift

## 6. Key Results and Impact
- Attrition scorecard deployed for retention targeting
- Identified high-risk policyholders for intervention
- Transparent model supporting business decision-making

## 7. Challenges and Solutions
- **Class Imbalance**: Non-renewal is a minority event → Appropriate sampling and evaluation metrics

## 8. Job Application Story
- **Situation**: Insurance policy churn represented significant revenue loss, but retention marketing lacked a data-driven way to identify which policyholders were most at risk of non-renewal.
- **Task**: I developed an attrition scorecard to predict non-renewal risk and enable targeted retention campaigns.
- **Action**: I engineered features from policy data, built an interpretable scorecard model with clear factor contributions, and validated lift for retention targeting to ensure the model would meaningfully improve campaign ROI.
- **Result**: Delivered an interpretable attrition scorecard enabling targeted retention interventions for at-risk policyholders, focusing marketing resources on the highest-risk segment rather than blanket campaigns.

## 9. Relevant Skills Demonstrated
- Scorecard modeling, churn prediction, feature engineering, model validation, insurance analytics

## 10. Best-Fit Job Types
- Data Scientist (Insurance/Retention), Customer Analytics Analyst, Churn Modeler

## 11. Resume Bullet Suggestions
- Developed insurance policy attrition scorecard for targeted retention campaigns, identifying at-risk policyholders for proactive intervention
- Engineered features from policy data and validated model lift to ensure meaningful improvement in retention campaign ROI
- Delivered interpretable scorecard model with clear factor contributions, enabling business stakeholders to understand and trust retention targeting

## 12. Interview Talking Points
- "I built a retention scorecard predicting policy non-renewal, enabling proactive campaigns to reduce churn."
- "Interpretability was key — business stakeholders needed to understand why a policyholder was flagged as at-risk, not just that they were. Scorecard models provide that transparency."

## 13. Evidence Found
- Attrition model scorecard files from 2012 for insurance policy renewal prediction
