# All Auto to Home — Allstate Cross-Sell Model

## 1. Executive Summary
Developed a cross-sell model for Allstate converting auto insurance customers to home insurance (AXH — Auto-to-Home). The project includes model reports comparing different versions with client field integration, enabling targeted cross-sell campaigns for one of the largest US insurance carriers.

## 2. Business / Product Background
Cross-selling home insurance to existing auto customers is a high-value strategy:
- Auto-to-home conversion increases customer lifetime value
- Multi-policy customers have higher retention rates
- Allstate as a major carrier represents significant business opportunity
- Client field integration allows carrier-specific model customization

## 3. Data Background
- **Model reports**: Allstate_AXH_w_client_field_model_report_*.xls (multiple versions)
- **Client integration**: Client field-specific model variants
- **Cross-sell focus**: Auto-to-Home (AXH) conversion probability

## 4. Technical Approach
- Cross-sell probability modeling for auto-to-home conversion
- Client field integration for Allstate-specific customization
- Base ratio analysis for cross-sell propensity
- Multi-version model comparison and refinement

## 5. My Role and Contribution
- Built Allstate auto-to-home cross-sell model with client field integration
- Compared model versions for optimization
- Delivered model reports for carrier deployment

## 6. Key Results and Impact
- Production-ready cross-sell model for Allstate's auto-to-home campaigns
- Client field integration enables carrier-specific targeting precision

## 7. Challenges and Solutions
- **Client Data Integration**: Allstate-specific fields need incorporation → Built variants with and without client fields for comparison

## 8. Job Application Story
- **Situation**: Allstate, one of the largest US auto insurers, needed to identify auto insurance customers most likely to purchase home insurance — a high-value cross-sell opportunity that required predictive modeling to target efficiently.
- **Task**: I built the auto-to-home (AXH) cross-sell model, integrating Allstate-specific client data fields to improve prediction beyond generic approaches.
- **Action**: I developed the AXH model with Allstate-specific client field integration, compared multiple model versions to optimize prediction accuracy, and validated the model against historical conversion data to ensure reliable targeting.
- **Result**: Delivered a production-ready cross-sell model enabling Allstate to target high-potential auto-to-home conversion candidates, improving campaign ROI by focusing marketing spend on the most likely converters.

## 9. Relevant Skills Demonstrated
- Cross-sell modeling
- Client data integration
- Insurance domain expertise
- Model comparison and optimization

## 10. Best-Fit Job Types
- Data Scientist (Insurance/Marketing)
- Product Data Scientist

## 11. Resume Bullet Suggestions
- Developed Allstate auto-to-home (AXH) cross-sell model with client field integration enabling targeted multi-policy conversion campaigns
- Compared multiple model versions and validated against historical conversion data to optimize cross-sell prediction accuracy
- Delivered production-ready scoring model for one of the largest US auto insurers, improving campaign ROI through precise targeting

## 12. Interview Talking Points
- "I built a cross-sell model for Allstate that identifies auto customers most likely to buy home insurance. Client field integration made the model significantly more predictive than generic approaches."
- "Cross-sell is a high-value use case because the auto customer base is already known — the challenge is predicting conversion probability accurately enough to justify targeted marketing spend."

## 13. Evidence Found
- **Allstate_AXH_w_client_field_model_report_*.xls** — Model reports with client fields
