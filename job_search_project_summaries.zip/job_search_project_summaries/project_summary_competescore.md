# CompeteScore — Insurance Competitive Ratio Modeling

## 1. Executive Summary
Developed comprehensive competitive positioning and scoring models for multiple major insurance carriers (Allstate, Travelers, Wawanesa). The CompeteScore suite models base ratios and competitive ratios to quantify how insurers compare against the market, supporting targeted marketing and competitive intelligence strategies.

## 2. Business / Product Background
Insurance carriers need to understand their competitive positioning in the market — where they are price-competitive, where they are not, and which customers are most likely to switch. CompeteScore provides:
- Competitive ratio models comparing carrier pricing vs. market benchmarks
- Base ratio analysis for market positioning
- Validation frameworks ensuring model reliability across carriers and time periods
- Actionable intelligence for targeted marketing campaigns and pricing decisions

Multiple carriers were served simultaneously: Allstate, Travelers, and Wawanesa, each requiring customized competitive analysis.

## 3. Data Background
- **Multiple carrier datasets**: Allstate, Travelers, Wawanesa competitive data
- **Model versions**: Extensive iteration (v2, v3+ for Allstate; multiple Travelers versions dated 20130913+)
- **Validation data**: Compete score validation datasets for model performance assessment
- **Premium file samples**: Competitive premium benchmarking data
- **50+ files** documenting the full modeling lifecycle across carriers

## 4. Technical Approach
- **Competitive Ratio Modeling**: Quantified carrier-to-market pricing relationships
- **Base Ratio Analysis**: Established market benchmarks for comparison
- **Multi-carrier customization**: Separate model parameters per carrier while maintaining consistent methodology
- **Validation Framework**: Systematic model validation across time periods and geographies
- **Excel-based Modeling**: Large-scale spreadsheet analytics with structured documentation
- **Iterative refinement**: Multiple versions (v2, v3) incorporating feedback and new data

## 5. My Role and Contribution
- Built competitive ratio models for multiple carriers (Allstate, Travelers, Wawanesa)
- Designed validation framework for cross-carrier model comparison
- Managed multi-version model development with systematic documentation
- Delivered carrier-specific insights for marketing targeting

## 6. Key Results and Impact
- Delivered competitive intelligence models for 3+ major insurance carriers
- Enabled data-driven marketing targeting based on competitive positioning
- Created reusable validation framework applicable across carrier engagements
- Supported carrier pricing decisions with market benchmarking

## 7. Challenges and Solutions
- **Multi-carrier complexity**: Each carrier has different data formats and competitive dynamics → Maintained consistent methodology with carrier-specific parameterization
- **Temporal validation**: Market conditions change → Built validation across multiple time periods
- **Version management**: Extensive iteration required → Systematic versioning (v2, v3) with clear documentation

## 8. Job Application Story
- **Situation**: Major insurance carriers including Allstate, Travelers, and Wawanesa needed to understand their competitive positioning relative to competitors to optimize pricing strategies and marketing targeting — but lacked quantitative benchmarks for market-level pricing comparisons.
- **Task**: I owned the development of competitive ratio models for multiple carrier clients simultaneously, defining the modeling methodology and managing each carrier's unique customization requirements.
- **Action**: I developed base ratio and competitive ratio models for 3+ major carriers, implementing a consistent core methodology while customizing parameters for each carrier's specific competitive landscape. I built a reusable validation framework ensuring reliability across time periods and geographies, iterated through multiple model versions based on stakeholder feedback from carrier marketing and pricing teams, and presented competitive insights that directly informed targeting strategies.
- **Result**: Delivered production-ready competitive intelligence models serving 3+ major insurance carriers, with the reusable validation framework reducing time-to-delivery for subsequent carrier onboarding. The competitive ratio scores enabled carriers to identify geographic areas where they were price-competitive and allocate marketing spend accordingly.

## 9. Relevant Skills Demonstrated
- Predictive modeling (competitive ratio analysis)
- Multi-stakeholder project management
- Insurance domain expertise
- Model validation and testing
- Data analysis and visualization
- Stakeholder communication
- Documentation and version control

## 10. Best-Fit Job Types
- Data Scientist (Insurance/Marketing)
- Product Data Scientist
- Analytics Lead
- Business Intelligence / Competitive Intelligence Analyst

## 11. Resume Bullet Suggestions
- Developed competitive ratio models for 3+ major insurance carriers (Allstate, Travelers, Wawanesa), providing quantitative market positioning benchmarks for pricing and marketing optimization
- Built reusable cross-carrier validation framework that reduced time-to-delivery for new carrier onboarding, with systematic multi-version refinement based on stakeholder feedback
- Managed concurrent modeling engagements across multiple carrier clients, customizing methodology for each carrier's competitive landscape while maintaining methodological consistency
- Delivered competitive intelligence insights directly informing carrier marketing spend allocation and geographic targeting strategies

## 12. Interview Talking Points
- **Multi-carrier management**: "I built competitive ratio models for Allstate, Travelers, and Wawanesa simultaneously. Each carrier has a unique competitive landscape, so I designed a core methodology that could be customized per carrier while maintaining consistency for cross-carrier benchmarking."
- **Reusable framework**: "The validation framework I designed was reusable across carrier engagements, which significantly reduced time-to-delivery when onboarding new carriers. This kind of reusable tooling was a pattern I applied across my 13 years of modeling work."
- **Business impact**: "The competitive ratio scores directly informed how carriers allocated marketing spend — identifying geographic areas where they were price-competitive and directing acquisition campaigns to those regions."

## 13. Evidence Found
- **allstate_competitive_ratio_model_*.xlsx** — Multiple versions (v2, v3) of Allstate competitive models
- **compete_score_validation_*.xlsx** — Validation framework files
- **travelers_compete_ratio_model_deliverables_20130913.xlsx** — Travelers carrier model
- **premium file sample.csv** — Premium benchmarking data
