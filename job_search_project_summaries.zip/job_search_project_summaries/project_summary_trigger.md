# Insurance Trigger — Campaign Trigger Pipeline

## 1. Executive Summary
Built a four-stage ECL pipeline on HPCC Systems for insurance trigger identification and campaign execution. The pipeline processes insurance trigger events — identifying customers likely to switch carriers — using LexID matching, transaction processing, competitive analysis, and non-NCF filtering to support targeted direct mail and marketing campaigns for carriers like Liberty Mutual and Progressive.

## 2. Business / Product Background
Insurance triggers are events (policy changes, inquiries, life events) that signal a consumer may be in-market for insurance. The trigger pipeline:
- Identifies consumers showing switching signals from insurance events
- Matches consumers via LexID for identity resolution
- Filters and scores triggers for campaign targeting
- Supports direct mail campaigns for carriers (Liberty Mutual, Progressive)
- Tracks trigger distribution and campaign effectiveness

## 3. Data Background
- **Pipeline stages**: 4-stage ECL processing (step0–step3)
- **Campaign data**: 30+ text files with 2019 trigger transaction data (January–September)
- **Carrier focus**: Liberty Mutual and Progressive campaign data
- **Storage**: Access database (trigger_camp.accdb), SQLite (trigger_camp.db), CSV exports
- **Distribution tracking**: trigger_distribution.xlsx
- **ECL scripts**: 8+ scripts in ECL/trigger/ subfolder

## 4. Technical Approach
- **Stage 0**: `step0_lexid_trigger.ecl` — LexID matching and identity resolution for trigger events
- **Stage 1**: `step1_trans.ecl` — Transaction processing and event normalization
- **Stage 2**: `step2_comp.ecl` — Competitive analysis and scoring
- **Stage 3**: `step3_non_ncf.ecl` — Non-NCF (Non-Carrier Filing) filtering for campaign targeting
- **Platform**: HPCC Systems with ECL for distributed processing
- **Campaign Tracking**: Access database and SQLite for campaign management; distribution analysis via Excel

## 5. My Role and Contribution
- Designed and built 4-stage ECL data pipeline for trigger identification
- Implemented LexID matching for consumer identity resolution
- Built competitive analysis stage for trigger scoring
- Managed campaign data across multiple carriers and time periods
- Tracked trigger distribution and campaign performance

## 6. Key Results and Impact
- Production pipeline processing trigger events for 9+ months of data (Jan–Sep 2019)
- Supported direct mail campaigns for Liberty Mutual and Progressive
- Automated trigger identification from raw insurance events through campaign-ready output
- 4-stage pipeline design enables modular processing and maintenance

## 7. Challenges and Solutions
- **Identity Resolution**: Consumers appear across multiple data sources → Used LexID matching in Stage 0 for reliable identity resolution
- **Data Volume**: 30+ trigger transaction files per campaign period → Built distributed ECL pipeline on HPCC
- **Campaign Management**: Multiple carriers and time periods → Structured storage across Access DB, SQLite, and CSV with distribution tracking

## 8. Job Application Story
- **Situation**: Major insurance carriers like Liberty Mutual and Progressive needed to identify consumers showing switching signals to target with retention and acquisition campaigns, but the process of extracting trigger events from raw insurance data, resolving consumer identities, and producing campaign-ready files required multi-stage data processing at scale across millions of insurance events.
- **Task**: I owned the design, implementation, and ongoing operational management of the end-to-end trigger identification pipeline, managing campaign execution across multiple carrier clients simultaneously.
- **Action**: I designed a 4-stage ECL pipeline on HPCC Systems: Stage 0 performs LexID matching for consumer identity resolution across data sources, Stage 1 normalizes insurance transaction events, Stage 2 runs competitive analysis and scoring to rank trigger strength, and Stage 3 applies NCF (Non-Carrier Filing) filtering to produce campaign-ready output. I managed campaign data delivery for Liberty Mutual and Progressive across 9 consecutive months (January–September 2019), tracking trigger distributions via Excel and Access databases, coordinating delivery schedules with carrier marketing teams, and ensuring data quality across 30+ monthly trigger transaction files.
- **Result**: Delivered a production trigger pipeline that automated what was previously a manual, multi-day data extraction process into a repeatable, modular 4-stage workflow. The pipeline supported 9 months of direct mail campaigns for two of America's largest insurance carriers, with trigger distribution tracking demonstrating consistent identification of in-market consumers for targeted acquisition.

## 9. Relevant Skills Demonstrated
- Data pipeline development (ECL/HPCC)
- Identity resolution (LexID matching)
- Campaign analytics and tracking
- Insurance domain expertise (triggers, switching behavior)
- Database management (Access, SQLite)
- Production system development

## 10. Best-Fit Job Types
- Data Engineer
- Data Scientist (Marketing/Insurance)
- Analytics Engineer
- Campaign Analytics Scientist

## 11. Resume Bullet Suggestions
- Designed and operated a 4-stage ECL pipeline on HPCC Systems for automated insurance trigger identification, supporting direct mail campaigns for Liberty Mutual and Progressive across 9 consecutive months
- Implemented LexID-based consumer identity resolution processing millions of insurance events, linking trigger signals to verified consumer profiles for campaign targeting
- Managed concurrent campaign data delivery for two of America's largest insurance carriers, coordinating delivery schedules with carrier marketing teams and ensuring data quality across 30+ monthly files
- Built competitive analysis and scoring stage that ranks trigger strength by switching likelihood, enabling carriers to prioritize high-value acquisition targets
- Automated a previously manual multi-day data extraction process into a repeatable, modular pipeline with trigger distribution tracking for ongoing campaign performance monitoring

## 12. Interview Talking Points
- **Pipeline architecture**: "I built a four-stage ECL pipeline for insurance trigger identification — identity resolution via LexID, transaction normalization, competitive scoring, and NCF filtering. Each stage is modular, so carrier-specific requirements can be swapped without rebuilding the entire pipeline."
- **Carrier management**: "I managed concurrent campaigns for Liberty Mutual and Progressive — two of the largest US auto insurance carriers. This required coordinating delivery schedules, ensuring data quality across 30+ monthly transaction files, and tracking trigger distributions to validate campaign targeting effectiveness."
- **Business impact**: "The pipeline automated what had been a manual, multi-day data extraction process. Over 9 months of continuous operation, it consistently identified in-market consumers for targeted direct mail acquisition campaigns."
- **Identity resolution at scale**: "The first pipeline stage uses LexID matching to resolve consumer identities across multiple data sources. This is critical — without reliable identity resolution, trigger signals get attributed to the wrong consumers, wasting carrier marketing spend."

## 13. Evidence Found
- **step0_lexid_trigger.ecl** — LexID matching stage
- **step1_trans.ecl** — Transaction processing stage
- **step2_comp.ecl** — Competitive analysis stage
- **step3_non_ncf.ecl** — NCF filtering stage
- **30+ text files** — 2019 trigger transaction data
- **trigger_camp.accdb, trigger_camp.db** — Campaign databases
- **trigger_distribution.xlsx** — Distribution tracking
- **8+ ECL files in ECL/trigger/** — Supporting scripts
