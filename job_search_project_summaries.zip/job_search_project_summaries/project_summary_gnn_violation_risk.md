# GNN Violation Risk Score — Graph Neural Network for Insurance Loss Cost Prediction (Project #24441)

## 1. Executive Summary
Led and supervised the development of a Graph Neural Network (GNN) model for predicting insurance loss cost from driver violation data, achieving a Gini coefficient of 0.1960 — a 137% improvement over the industry-standard points-based approach (Gini 0.0825). The model operates on 20M LexID records with 140M linked VIN records, using a 10M/10M train/validation split. This project represents a paradigm shift from legacy points-based carrier rating systems to ML-based violation risk scoring, and complements the Hierarchical Transformer embedding work as part of a broader deep learning strategy for insurance analytics.

## 2. Business / Product Background
The insurance industry has historically relied on points-based rating systems for assessing driver violation risk — assigning fixed penalty values to different violation types and summing them. This approach has fundamental limitations:
- It ignores temporal patterns and violation sequences
- It treats all violations of the same type identically regardless of context
- It cannot capture interactions between different violation types
- It has reached its predictive ceiling after decades of incremental refinement

The GNN Violation Risk Score project aims to replace this paradigm entirely by learning violation risk representations directly from graph-structured driver-vehicle-violation data, enabling carriers to make more accurate pricing decisions.

This project is part of the broader insurance analytics strategy that Prasanth Kambhatla (senior leadership) endorsed to the Quarterly Model Governance Oversight Committee, stating: *"we will be leveraging this transformer technology for creating embeddings for insurance products in the future."*

## 3. Data Background
- **Modeling records**: 20M LexID (driver identity) records
- **VIN records**: 140M Vehicle Identification Number records linked to LexIDs
- **Training set**: 10M records
- **Validation set**: 10M records
- **Target variable**: Loss cost prediction over a 6-month horizon following lookback date
- **Graph structure**: Driver nodes (LexID) connected to vehicle nodes (VIN) with violation/event edges
- **Source data**: Same violation/MVR data pipeline as the Transformer embedding project (Project #24441 shared infrastructure)

## 4. Technical Approach
- **Primary model**: Graph Neural Network (GNN) — learns node-level and edge-level representations from the driver-vehicle-violation graph
- **Benchmark comparisons**:
  | Model | Gini Coefficient | vs. Industry |
  |---|---|---|
  | Industry points-based | 0.0825 | baseline |
  | Tweedie GLM | 0.1188 | +44% |
  | Tweedie GBM | 0.1392 | +69% |
  | **GNN** | **0.1960** | **+137%** |
- **Loss function**: Tweedie loss (consistent with insurance severity modeling)
- **Evaluation metric**: Gini coefficient on validation set
- **Scale**: 20M modeling records, 140M VIN records, 10M train/validation splits
- **Next phase**: VIN-level feature integration to further improve predictive power
- **Complementary to**: Hierarchical Transformer embeddings (same project number #24441) — the GNN and Transformer approaches represent parallel deep learning strategies for violation risk scoring

## 5. My Role and Contribution
- **Project lead and supervisor**: Owned the strategic direction and supervised model development (with Vu Tran as primary modeler)
- **Data asset provision**: Provided access to the 20M LexID + 140M VIN record datasets from the insurance analytics data lake
- **Architecture guidance**: Directed the GNN approach as a complement to the Hierarchical Transformer, ensuring both strategies shared infrastructure and data pipelines
- **Results analysis**: Reviewed and validated the benchmark comparisons (GNN vs. industry points, GLM, GBM)
- **Stakeholder communication**: Presented results to senior leadership and the Model Governance Oversight Committee
- **Customer-facing materials**: Provided presentation materials for CAM 2025 (Customer Advisory Meeting, 252 customers) where the violation embedding/GNN work was featured
- **Strategic vision**: Articulated the shift from points-based to ML-based violation risk scoring as a product strategy for carrier clients

## 6. Key Results and Impact
- **GNN Gini: 0.1960** — 137% improvement over industry-standard points-based approach (0.0825)
- **Outperformed all traditional methods**: GNN > Tweedie GBM (0.1392) > Tweedie GLM (0.1188) > Industry points (0.0825)
- **Scale**: Validated on 10M holdout records — results are statistically robust
- **CAM 2025 presentation**: Work featured at the 29th annual Customer Advisory Meeting before 252 insurance customers, generating 385 hot leads (session: "Everything's Bigger in Texas; Lasso the Value of Violation Data")
- **Strategic endorsement**: Prasanth Kambhatla endorsed the approach to the Model Governance Oversight Committee for broader product adoption
- **Paradigm shift**: Demonstrates that ML-based violation risk scoring can fundamentally replace legacy points-based systems

## 7. Challenges and Solutions
- **Graph scale**: 140M VIN records linked to 20M LexIDs creates a massive graph → Designed efficient data pipelines and sampling strategies for GNN training
- **Benchmark rigor**: Needed to convincingly demonstrate superiority over industry standard → Ran head-to-head comparisons against points-based, GLM, and GBM approaches on identical 10M validation sets
- **Stakeholder buy-in for paradigm shift**: Carriers have used points-based systems for decades → Used CAM presentation and governance committee endorsement to build momentum
- **Complementary architecture coordination**: Running GNN and Transformer in parallel required shared data infrastructure and aligned evaluation → Managed both under Project #24441 with shared data assets

## 8. Job Application Story
- **Situation**: The insurance industry has relied on points-based violation rating systems for decades, assigning fixed penalty values to violations. This approach has hit its predictive ceiling. LexisNexis had the data assets (20M driver records, 140M VIN records) to fundamentally reimagine violation risk scoring using deep learning.
- **Task**: As Principal Data Scientist I, I led the development of a Graph Neural Network approach to violation risk scoring, supervising model development, providing data assets, and driving stakeholder buy-in for a paradigm shift from points-based to ML-based rating.
- **Action**: I directed the GNN architecture as a complement to our Hierarchical Transformer embeddings, both operating under Project #24441 with shared data infrastructure. I provided the 20M LexID + 140M VIN record datasets, guided the modeling approach, and ran systematic benchmark comparisons against industry points (Gini 0.0825), Tweedie GLM (0.1188), and Tweedie GBM (0.1392). I presented results to the Quarterly Model Governance Oversight Committee and provided materials for the CAM 2025 customer conference.
- **Result**: The GNN achieved Gini 0.1960 — a 137% improvement over industry benchmarks — validated on a 10M holdout set. Senior leadership endorsed the approach for future product adoption. The work was featured at the 29th annual Customer Advisory Meeting before 252 insurance customers, generating 385 leads. This project demonstrates that ML-based violation risk scoring can fundamentally replace legacy points-based systems across the industry.

## 9. Relevant Skills Demonstrated
- Graph Neural Networks (GNN)
- Deep learning for insurance loss cost prediction
- Project leadership and team supervision
- Large-scale data modeling (20M+ records)
- Benchmark evaluation methodology
- Tweedie loss / insurance severity modeling
- Customer-facing presentation and stakeholder influence
- Model governance and oversight committee participation
- Strategic product vision (points-based → ML-based paradigm shift)

## 10. Source
This project was identified from email evidence (Vu Tran project updates, Prasanth Kambhatla governance committee communications, Donna Stokes CAM marketing updates) — supplementing the existing Transformer embedding project folder. The GNN work is a parallel track under the same Project #24441.
