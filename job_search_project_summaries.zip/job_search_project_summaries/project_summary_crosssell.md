# Crosssell — Wawanesa Cross-Sell Model

## 1. Executive Summary
Developed a cross-sell targeting model for Wawanesa, a regional Canadian insurer, with a strategic roadmap. The non-segmented model approach with geographic focus on California represents a targeted cross-sell solution for a niche carrier market.

## 2. Business / Product Background
Wawanesa (a BC, Canada-based insurer operating in California) needed cross-sell modeling to identify existing customers likely to purchase additional products. The model supports efficient cross-sell campaign targeting.

## 3. Data Background
- **Model documentation**: model_document_wawanesa_cross_sell_model*.xlsx (multiple versions)
- **Strategic planning**: roadmap.xlsx — product roadmap
- **Geographic focus**: California market

## 4. Technical Approach
- Non-segmented cross-sell probability modeling
- California geographic focus for Wawanesa market
- Strategic roadmap alignment with model development
- Multiple model version iterations

## 5. My Role and Contribution
- Built Wawanesa cross-sell model with California-specific focus
- Developed strategic roadmap for cross-sell targeting
- Iterated through multiple model versions

## 6. Key Results and Impact
- Cross-sell targeting model for Wawanesa's California market
- Strategic roadmap aligning model development with business goals

## 7. Challenges and Solutions
- **Niche Market**: Wawanesa operates in a specific geographic segment → Focused model on California market

## 8. Job Application Story
- **Situation**: Wawanesa, a Canadian insurer expanding in the California market, needed cross-sell targeting capabilities to maximize customer lifetime value from their existing policyholder base, but lacked predictive models for identifying cross-sell opportunities.
- **Task**: I owned the development of a cross-sell model for Wawanesa's California operations, including defining the modeling approach and creating a strategic roadmap for ongoing model evolution.
- **Action**: I developed a non-segmented cross-sell model focused on the California market, analyzing policyholder attributes that predict cross-sell receptivity. I created a strategic development roadmap outlining future segmentation, feature enrichment, and model refresh plans for Wawanesa's ongoing use.
- **Result**: Delivered cross-sell targeting capability enabling Wawanesa to identify high-potential cross-sell prospects in their California book, with a strategic roadmap guiding ongoing model development and refinement.

## 9. Relevant Skills Demonstrated
- Cross-sell modeling, strategic planning, insurance domain expertise

## 10. Best-Fit Job Types
- Data Scientist (Insurance), Product Data Scientist

## 11. Resume Bullet Suggestions
- Developed cross-sell targeting model for Wawanesa Insurance's California market, enabling data-driven identification of high-potential cross-sell prospects from existing policyholders
- Created strategic development roadmap for ongoing model evolution, including segmentation and feature enrichment plans for sustained targeting improvement
- Analyzed cross-sell receptivity patterns across policyholder attributes to identify actionable targeting criteria for marketing campaigns

## 12. Interview Talking Points
- "I built a cross-sell model for Wawanesa's California market and created a strategic roadmap for ongoing development. Cross-sell targeting requires understanding which policyholders are likely to add additional coverage — different drivers than acquisition targeting."
- "Wawanesa is a Canadian insurer expanding in the US, so the model needed to work with their specific California book rather than national data. I designed the approach to accommodate their data footprint while maximizing targeting precision."

## 13. Evidence Found
- **model_document_wawanesa_cross_sell_model*.xlsx** — Model documentation
- **roadmap.xlsx** — Strategic roadmap
