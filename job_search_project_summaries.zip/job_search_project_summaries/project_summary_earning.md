# Earning — Financial Earnings Analysis Tool

## 1. Executive Summary
Built a personal financial analysis toolkit using Python for earnings tracking, fundamental analysis, and investment monitoring. The project scrapes earnings dates from Yahoo Finance, processes company financial statements, and includes monitoring dashboards — demonstrating proficiency in web scraping, financial data APIs, and automated Excel reporting.

## 2. Business / Product Background
Personal investment research project for tracking company earnings, financial fundamentals, and market monitoring:
- Automated earnings date scraping from Yahoo Finance
- Financial statement parsing and analysis
- Monitoring dashboard for portfolio tracking
- Excel automation via xlwings for report generation

## 3. Data Background
- **Data sources**: Yahoo Finance (web scraping), financial APIs
- **Stored data**: Pickled Python objects (ReportsFinStatements.p, ReportsFinSummary.p, ReportSnapshot.p, RESC.p)
- **Output formats**: Jupyter notebooks, Excel reports
- **Financial metrics**: Earnings dates, financial statements, fundamentals

## 4. Technical Approach
- **Web Scraping**: BeautifulSoup for Yahoo Finance earnings data extraction
- **Data Processing**: pandas for financial data manipulation
- **Excel Automation**: xlwings for automated report generation
- **Monitoring**: Monitoring.ipynb for dashboard-style tracking
- **Persistence**: Python pickle for data caching and historical tracking
- **Notebooks**: earning.ipynb, ib_fundermental.ipynb, Monitoring.ipynb

## 5. My Role and Contribution
- Designed and built the entire financial analysis toolkit
- Implemented web scraping for earnings date collection
- Built monitoring dashboard for portfolio tracking
- Created automated Excel reporting pipeline

## 6. Key Results and Impact
- Automated earnings tracking from Yahoo Finance
- Financial statement analysis pipeline for investment research
- Monitoring dashboard for ongoing portfolio oversight
- Demonstrates full-stack data science skills applied to financial domain

## 7. Challenges and Solutions
- **Data Acquisition**: Financial data not readily available in structured format → Built web scraper using BeautifulSoup
- **Data Persistence**: Need historical tracking across sessions → Used pickle for data caching

## 8. Job Application Story
- **Situation**: Tracking company earnings, analyzing financial fundamentals, and monitoring investment portfolios required an automated, systematic approach rather than manual research.
- **Task**: I designed and built an end-to-end financial analysis toolkit from scratch, covering the full data pipeline from web scraping through automated reporting.
- **Action**: Using Python, I scraped earnings dates from Yahoo Finance with BeautifulSoup, processed financial statements with pandas, built monitoring dashboards in Jupyter, and automated Excel reports via xlwings — demonstrating the same full-stack data engineering skills I apply to production analytics.
- **Result**: Created a comprehensive financial analysis toolkit demonstrating full-stack data science skills — from web scraping and data engineering to visualization and automated reporting — the same pipeline architecture patterns used in production insurance analytics.

## 9. Relevant Skills Demonstrated
- Python (pandas, BeautifulSoup, xlwings)
- Web scraping
- Financial data analysis
- Jupyter notebook development
- Excel automation
- Data pipeline design
- Visualization and dashboarding

## 10. Best-Fit Job Types
- Data Scientist
- Quantitative Analyst
- Financial Data Analyst
- AI / ML Engineer

## 11. Resume Bullet Suggestions
- Built financial analysis toolkit with automated Yahoo Finance earnings scraping using BeautifulSoup and pandas pipeline
- Developed monitoring dashboard in Jupyter for portfolio tracking with xlwings-based automated Excel reporting
- Implemented end-to-end data pipeline from web scraping through financial statement analysis to automated report generation

## 12. Interview Talking Points
- "I built a financial analysis toolkit that scrapes earnings data from Yahoo Finance, processes financial statements, and generates automated Excel reports — the same pipeline architecture I use in production analytics."
- "The project demonstrates my ability to build end-to-end data pipelines from web scraping through automated reporting. These are the same patterns — data ingestion, transformation, visualization, automated output — that I apply to insurance analytics at scale."

## 13. Evidence Found
- **earning.ipynb** — Earnings tracking and analysis
- **ib_fundermental.ipynb** — Fundamental analysis notebook
- **Monitoring.ipynb** — Monitoring dashboard
- **ReportsFinStatements.p, ReportsFinSummary.p, ReportSnapshot.p, RESC.p** — Pickled financial data
