# Inquiry / Proximity Model — Multi-State Validation

## 1. Executive Summary
Developed a proximity model for insurance inquiry analysis with 24-month lookback across 20 states. The project involved 5 progressive validation iterations (v1–v5) examining carrier inquiry patterns and switching behavior, with data return analysis and performance presentations documenting the model's evolution.

## 2. Business / Product Background
Insurance inquiries (shopping signals) indicate customer intent and potential switching behavior. The proximity model analyzes inquiry patterns to:
- Predict customer switching likelihood based on inquiry timing and frequency
- Enable carriers to proactively retain at-risk customers
- Optimize marketing campaigns by targeting high-switching-probability prospects
- Provide 20-state coverage for broad market applicability

## 3. Data Background
- **Temporal scope**: 24-month lookback window for inquiry pattern analysis
- **Geographic scope**: 20-state coverage (data_return_24M_20state_sample.csv)
- **Features**: Inquiry frequency, timing, carrier source, geographic proximity signals
- **Validation**: 5 progressive iterations (prox_model_validation_*.pptx, v1–v5)

## 4. Technical Approach
- **Proximity Modeling**: Spatial/temporal analysis of inquiry patterns
- **24-month Window**: Long lookback to capture cyclical switching behavior
- **Multi-state Coverage**: 20-state model with geographic segmentation
- **Iterative Validation**: 5 validation iterations with progressive refinement
- **Performance Presentations**: Stakeholder-facing validation at each iteration

## 5. My Role and Contribution
- Built and validated proximity model across 20 states with 24-month lookback
- Conducted 5 iterative validation cycles with progressive model improvement
- Presented performance results to stakeholders at each validation stage
- Analyzed carrier inquiry patterns for switching behavior insights

## 6. Key Results and Impact
- Delivered 20-state proximity model for inquiry-based switching prediction
- 5 validation iterations demonstrate thorough model evaluation
- 24-month lookback captures long-term switching patterns
- Model supports proactive customer retention strategies

## 7. Challenges and Solutions
- **Temporal Complexity**: Customer switching behavior varies by season and economic conditions → Used 24-month window to capture full cycles
- **Geographic Variation**: Inquiry patterns differ by state → Built multi-state model with geographic segmentation
- **Validation Rigor**: 5 iterations needed to achieve stakeholder confidence → Progressive validation approach with clear documentation at each stage

## 8. Job Application Story
- **Situation**: Insurance carriers needed to predict customer switching behavior to enable proactive retention — losing a policyholder is significantly more expensive than retaining one, and inquiry patterns (consumers shopping for quotes) are the strongest leading indicator of intent to switch.
- **Task**: I owned the development of a proximity-based switching prediction model analyzing 24 months of inquiry data across 20 US states.
- **Action**: I built the model with a 24-month lookback window to capture long-term shopping patterns, engineered inquiry frequency, timing, and geographic proximity features, and conducted 5 progressive validation iterations with stakeholder presentations at each stage. I analyzed switching behavior signals across state-level segments and presented findings to carrier clients who used the scores for retention campaign targeting.
- **Result**: Delivered a validated 20-state switching prediction model that enabled carriers to identify at-risk customers before they churned. The 5-iteration validation process ensured the model met reliability standards across diverse state markets, and the inquiry-based features became a reusable signal in subsequent LexisNexis insurance analytics products.

## 9. Relevant Skills Demonstrated
- Predictive modeling (proximity/inquiry analysis)
- Temporal analysis (24-month windows)
- Multi-state geographic modeling
- Model validation (5 iterations)
- Stakeholder communication
- Insurance domain expertise

## 10. Best-Fit Job Types
- Data Scientist (Insurance/Marketing)
- Product Data Scientist
- Applied Scientist

## 11. Resume Bullet Suggestions
- Developed 20-state insurance switching prediction model analyzing 24 months of inquiry data, enabling carriers to identify at-risk customers for proactive retention campaigns
- Conducted 5 progressive validation iterations with carrier stakeholder presentations, demonstrating model reliability across diverse state markets
- Engineered inquiry-based behavioral features (frequency, timing, geographic proximity) that became reusable signals in subsequent LexisNexis insurance analytics products
- Analyzed state-level switching patterns revealing distinct market dynamics, informing geographic segmentation strategy for retention campaigns

## 12. Interview Talking Points
- **Business insight**: "Inquiry patterns are the strongest leading indicator of insurance switching behavior — when a consumer starts shopping for quotes, they're signaling intent to switch. I built a model using 24 months of inquiry data across 20 states to predict which policyholders are at risk of churning."
- **Validation rigor**: "Five progressive validation iterations ensured the model met reliability standards across diverse state markets. Each iteration was presented to carrier stakeholders, with refinements driven by their domain expertise."
- **Reusable impact**: "The inquiry-based features I engineered — frequency, timing, geographic proximity — became reusable signals in subsequent LexisNexis products, extending the project's impact beyond the original use case."

## 13. Evidence Found
- **data_return_24M_20state_sample.csv** — 20-state inquiry data with 24-month lookback
- **prox_model_validation_*.pptx** (v1–v5) — Progressive validation presentations
