# For Margie — Competitive Ratio Standard/Non-Standard Market

## 1. Executive Summary
Developed competitive ratio models analyzing standard vs. non-standard insurance market attractiveness with Allstate focus. The work was prepared for stakeholder "Margie" with analysis separating standard and non-standard market segments for differentiated competitive intelligence.

## 2. Business / Product Background
Insurance markets divide into standard (preferred risk) and non-standard (higher risk) segments with fundamentally different competitive dynamics. The analysis:
- Quantifies competitive positioning in standard vs. non-standard segments
- Identifies market attractiveness by segment
- Supports segment-specific marketing strategies for Allstate

## 3. Data Background
- **Model documentation**: allstate_competitive_ratio_model_document*.xlsx (multiple versions)
- **Attractiveness analysis**: attract_std.xlsx (standard market), attract_non-std.xlsx (non-standard market)

## 4. Technical Approach
- Competitive ratio modeling by market segment (standard/non-standard)
- Market attractiveness scoring for each segment
- Allstate-specific competitive analysis

## 5. My Role and Contribution
- Built segment-specific competitive ratio models
- Analyzed standard vs. non-standard market attractiveness
- Prepared analysis for senior stakeholder communication

## 6. Key Results and Impact
- Segment-differentiated competitive intelligence for Allstate
- Standard vs. non-standard market attractiveness insights

## 7. Challenges and Solutions
- **Segment Differences**: Standard and non-standard markets have different competitive dynamics → Built separate analyses for each segment

## 8. Job Application Story
- **Situation**: Allstate needed competitive positioning analysis differentiated by standard and non-standard market segments — two fundamentally different competitive landscapes requiring separate analytical approaches.
- **Task**: I built segment-specific competitive ratio models with market attractiveness scoring for both segments.
- **Action**: I developed separate analyses for standard and non-standard markets, quantifying competitive ratios and market attractiveness by geography, and presented the differential insights to Allstate stakeholders.
- **Result**: Delivered segment-specific competitive intelligence enabling Allstate to tailor marketing strategies by market segment, recognizing that growth opportunities differ fundamentally between standard and non-standard books.

## 9. Relevant Skills Demonstrated
- Market segmentation, competitive analysis, stakeholder communication, insurance domain expertise

## 10. Best-Fit Job Types
- Data Scientist (Insurance), Product Data Scientist, Analytics Lead

## 11. Resume Bullet Suggestions
- Developed standard/non-standard market competitive ratio models for Allstate, enabling segment-differentiated marketing strategies
- Quantified market attractiveness by geography for both standard and non-standard insurance segments with separate analytical frameworks
- Delivered segment-specific insights to carrier stakeholders, informing differentiated growth strategies for a top-5 US insurer

## 12. Interview Talking Points
- "I analyzed competitive positioning separately for standard and non-standard insurance markets — they have fundamentally different dynamics, and aggregating them masks the real growth opportunities."
- "Understanding segment-level competitive dynamics is critical for carrier strategy — a carrier strong in standard may be weak in non-standard, and the marketing approach must differ accordingly."

## 13. Evidence Found
- **allstate_competitive_ratio_model_document*.xlsx** — Competitive ratio models
- **attract_std.xlsx, attract_non-std.xlsx** — Market attractiveness by segment
